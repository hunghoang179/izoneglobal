<?php
//Menu
$menu_id = kt_add_menu( 57, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 881, $menu_id, 0, 'Home', 'custom', 881, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/', '', '0', '' );

kt_add_menu_item( 964, $menu_id, 881, 'Home 1', 'custom', 964, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 965, $menu_id, 881, 'Home 2', 'custom', 965, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 966, $menu_id, 881, 'Home 3', 'custom', 966, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/', '', '0', '' );

kt_add_menu_item( 967, $menu_id, 881, 'Home 4', 'custom', 967, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/', '', '0', '' );

kt_add_menu_item( 968, $menu_id, 881, 'Home 5', 'custom', 968, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 969, $menu_id, 881, 'Home 6', 'custom', 969, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 970, $menu_id, 881, 'Home 7', 'custom', 970, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/', '', '0', '' );

kt_add_menu_item( 971, $menu_id, 881, 'Home 8', 'custom', 971, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option8/', '', '0', '' );

kt_add_menu_item( 972, $menu_id, 881, 'Home 9', 'custom', 972, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option9/', '', '0', '' );

kt_add_menu_item( 973, $menu_id, 881, 'Home 11', 'custom', 973, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/', '', '0', '' );

kt_add_menu_item( 974, $menu_id, 881, 'Home 12', 'custom', 974, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option12/', '', '0', '' );

kt_add_menu_item( 975, $menu_id, 881, 'Home 13', 'custom', 975, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option13/', '', '0', '' );

kt_add_menu_item( 976, $menu_id, 881, 'Home 14', 'custom', 976, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option14/', '', '0', '' );

kt_add_menu_item( 883, $menu_id, 0, 'Fashion', 'product_cat', 40, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/fashion/', 'enabled', '255', '' );

kt_add_menu_item( 884, $menu_id, 0, 'Foods', 'product_cat', 41, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 885, $menu_id, 0, 'Furniture', 'product_cat', 42, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 887, $menu_id, 0, 'Sports', 'product_cat', 50, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/sports/', '', '0', '' );

kt_add_menu_item( 886, $menu_id, 0, 'Jewelry', 'product_cat', 43, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 882, $menu_id, 0, 'Digital', 'product_cat', 39, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/', '', '0', '' );

kt_add_menu_item( 888, $menu_id, 882, 'Accessories', 'product_cat', 52, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/accessories/', '', '0', '' );

kt_add_menu_item( 890, $menu_id, 882, 'Mobile', 'product_cat', 45, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 891, $menu_id, 882, 'Notebook', 'product_cat', 46, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 889, $menu_id, 882, 'Laptop', 'product_cat', 44, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 892, $menu_id, 882, 'Television', 'product_cat', 51, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option9/product-category/digital/television/', '', '0', '' );

kt_add_menu_item( 940, $menu_id, 0, 'Blog', 'page', 171, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option9/blog/', '', '0', '' );
