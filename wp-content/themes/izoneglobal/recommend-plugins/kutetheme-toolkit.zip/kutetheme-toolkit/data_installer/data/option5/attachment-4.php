<?php
kt_download_media(1307, 'J1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/J12.jpg');

kt_download_media(1308, 'J2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/J21.jpg');

kt_download_media(1309, 'J3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/J31.jpg');

kt_download_media(1310, 'J5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/J5.jpg');

kt_download_media(1313, 'S2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/S21.jpg');
