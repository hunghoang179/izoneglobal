<?php
kt_download_media(2278, '40', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/40.jpg');

kt_download_media(2279, '41', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/41.jpg');

kt_download_media(2280, '42', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/42.jpg');

kt_download_media(2281, '43', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/43.jpg');

kt_download_media(2282, '44', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/44.jpg');

kt_download_media(2283, '45', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/45.jpg');

kt_download_media(2284, '46', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/46.jpg');
