<?php
//Menu
$menu_id = kt_add_menu( 148, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 2242, $menu_id, 0, 'Vietnamese Pho', 'custom', 2242, 'custom', '#', '', '', '' );

kt_add_menu_item( 2243, $menu_id, 0, 'Noodles', 'custom', 2243, 'custom', '#', '', '', '' );

kt_add_menu_item( 2244, $menu_id, 0, 'Seafood', 'custom', 2244, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 149, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 2323, $menu_id, 0, 'Electronic', 'product_cat', 79, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/electronic/', '', '0', '2417' );

kt_add_menu_item( 2324, $menu_id, 0, 'Sport & Outdoors', 'product_cat', 105, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/sport-outdoor/', 'enabled', '766', '2418' );

kt_add_menu_item( 2325, $menu_id, 0, 'Smartphone & Tablets', 'product_cat', 104, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/smartphone-tablets/', '', '0', '2419' );

kt_add_menu_item( 2327, $menu_id, 0, 'Health & Beauty Bags', 'product_cat', 85, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/health-beauty-bags/', 'enabled', '764', '2420' );

kt_add_menu_item( 2326, $menu_id, 0, 'Shoes & Accessories', 'product_cat', 101, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/shoes-accessories/', '', '0', '2421' );

kt_add_menu_item( 2330, $menu_id, 0, 'Toys & Hobbies', 'product_cat', 113, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/toys-hobbies/', '', '0', '2422' );

kt_add_menu_item( 2328, $menu_id, 0, 'Computers & Networking', 'product_cat', 131, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/computers-networking/', '', '0', '2423' );

kt_add_menu_item( 2332, $menu_id, 0, 'Cameras & Photo', 'product_cat', 127, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/cameras-photo/', '', '0', '2426' );

kt_add_menu_item( 2598, $menu_id, 0, 'Chairs & Recliners', 'product_cat', 129, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/furniture/chairs-recliners/', '', '0', '2425' );

kt_add_menu_item( 2599, $menu_id, 0, 'Office Furniture', 'product_cat', 98, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/furniture/office-furniture/', '', '0', '2427' );

kt_add_menu_item( 2600, $menu_id, 0, 'Diamond Jewelry', 'product_cat', 132, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/jewelry/diamond-jewelry/', '', '0', '2424' );

kt_add_menu_item( 2333, $menu_id, 0, 'Television', 'product_cat', 109, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/television-2/', '', '0', '2427' );

kt_add_menu_item( 2334, $menu_id, 0, 'Fashion', 'product_cat', 80, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '2425' );

kt_add_menu_item( 2335, $menu_id, 0, 'Furniture', 'product_cat', 83, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/furniture/', '', '0', '2427' );

kt_add_menu_item( 2597, $menu_id, 0, 'Digital', 'product_cat', 78, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/', '', '0', '2426' );

//Menu
$menu_id = kt_add_menu( 150, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 2255, $menu_id, 0, 'Italian Pizza', 'custom', 2255, 'custom', '#', '', '', '' );

kt_add_menu_item( 2256, $menu_id, 0, 'French Cakes', 'custom', 2256, 'custom', '#', '', '', '' );

kt_add_menu_item( 2257, $menu_id, 0, 'Tops', 'custom', 2257, 'custom', '#', '', '', '' );

kt_add_menu_item( 2258, $menu_id, 0, 'Tops', 'custom', 2258, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 151, 'Company', '' );

 // Menu Item
kt_add_menu_item( 2285, $menu_id, 0, 'About Us', 'custom', 2285, 'custom', '#', '', '', '' );

kt_add_menu_item( 2286, $menu_id, 0, 'Testimonials', 'custom', 2286, 'custom', '#', '', '', '' );

kt_add_menu_item( 2287, $menu_id, 0, 'Affiliate Program', 'custom', 2287, 'custom', '#', '', '', '' );

kt_add_menu_item( 2288, $menu_id, 0, 'Terms & Conditions', 'custom', 2288, 'custom', '#', '', '', '' );

kt_add_menu_item( 2289, $menu_id, 0, 'Contact Us', 'custom', 2289, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 152, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 2295, $menu_id, 0, 'Company Info - Partnerships', 'custom', 2295, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 187, 'Custom Footer', 'custom_footer_menu' );

 // Menu Item
kt_add_menu_item( 2428, $menu_id, 0, 'About Us', 'custom', 2428, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2429, $menu_id, 0, 'Affiliates', 'custom', 2429, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2430, $menu_id, 0, 'Careers', 'custom', 2430, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2431, $menu_id, 0, 'Privacy Policy', 'custom', 2431, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2432, $menu_id, 0, 'Terms of Use', 'custom', 2432, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2433, $menu_id, 0, 'Contact Us', 'custom', 2433, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 154, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 2270, $menu_id, 0, 'Mobile', 'custom', 2270, 'custom', '#', '', '', '' );

kt_add_menu_item( 2271, $menu_id, 0, 'Tablets', 'custom', 2271, 'custom', '#', '', '', '' );

kt_add_menu_item( 2272, $menu_id, 0, 'Laptop', 'custom', 2272, 'custom', '#', '', '', '' );

kt_add_menu_item( 2273, $menu_id, 0, 'Memory Cards', 'custom', 2273, 'custom', '#', '', '', '' );

kt_add_menu_item( 2274, $menu_id, 0, 'Accessories', 'custom', 2274, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 155, 'euro', '' );

 // Menu Item
kt_add_menu_item( 2247, $menu_id, 0, 'Greek Potatoes', 'custom', 2247, 'custom', '#', '', '', '' );

kt_add_menu_item( 2259, $menu_id, 0, 'Famous Spaghetti', 'custom', 2259, 'custom', '#', '', '', '' );

kt_add_menu_item( 2260, $menu_id, 0, 'Famous Spaghetti', 'custom', 2260, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 156, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 2348, $menu_id, 0, 'Skirts', 'custom', 2348, 'custom', '#', '', '', '' );

kt_add_menu_item( 2349, $menu_id, 0, 'Jackets', 'custom', 2349, 'custom', '#', '', '', '' );

kt_add_menu_item( 2350, $menu_id, 0, 'Tops', 'custom', 2350, 'custom', '#', '', '', '' );

kt_add_menu_item( 2354, $menu_id, 0, 'Scarves', 'custom', 2354, 'custom', '#', '', '', '' );

kt_add_menu_item( 2355, $menu_id, 0, 'Pants', 'custom', 2355, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 157, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 2263, $menu_id, 0, 'Hamberger', 'custom', 2263, 'custom', '#', '', '', '' );

kt_add_menu_item( 2264, $menu_id, 0, 'Pizza', 'custom', 2264, 'custom', '#', '', '', '' );

kt_add_menu_item( 2265, $menu_id, 0, 'Noodles', 'custom', 2265, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 161, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 2343, $menu_id, 0, 'Shoes', 'custom', 2343, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2344, $menu_id, 0, 'Clothing', 'custom', 2344, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2345, $menu_id, 0, 'Tops', 'custom', 2345, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2346, $menu_id, 0, 'Scarves', 'custom', 2346, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2347, $menu_id, 0, 'Accessories', 'custom', 2347, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 162, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 2357, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option4/', '', '0', '' );

kt_add_menu_item( 2360, $menu_id, 2357, 'Home 1', 'custom', 2360, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 2361, $menu_id, 2357, 'Home 2', 'custom', 2361, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 2362, $menu_id, 2357, 'Home 6', 'custom', 2362, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 2248, $menu_id, 0, 'Fashion', 'product_cat', 80, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', 'enabled', '55', '' );

kt_add_menu_item( 2251, $menu_id, 0, 'Sports', 'product_cat', 106, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 2249, $menu_id, 0, 'Foods', 'product_cat', 82, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 2252, $menu_id, 0, 'Digital', 'product_cat', 78, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/', '', '0', '' );

kt_add_menu_item( 2275, $menu_id, 2252, 'Mobile', 'custom', 2275, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 2276, $menu_id, 2252, 'Tablets', 'custom', 2276, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/', '', '0', '' );

kt_add_menu_item( 2277, $menu_id, 2252, 'Laptop', 'custom', 2277, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 2278, $menu_id, 2252, 'Notebook', 'custom', 2278, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 2279, $menu_id, 2252, 'Accessories', 'custom', 2279, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/digital/', '', '0', '' );

kt_add_menu_item( 2253, $menu_id, 0, 'Furniture', 'product_cat', 83, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 2254, $menu_id, 0, 'Jewelry', 'product_cat', 87, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 2356, $menu_id, 0, 'Blog', 'page', 1188, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option4/sample-page-2-2/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 163, 'Men&#039;s', '' );

 // Menu Item
kt_add_menu_item( 2235, $menu_id, 0, 'Jackets', 'product_cat', 141, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/mens/jackets/', '', '', '' );

kt_add_menu_item( 2236, $menu_id, 0, 'Skirts', 'product_cat', 103, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/mens/skirts/', '', '', '' );

kt_add_menu_item( 2237, $menu_id, 0, 'Tops', 'product_cat', 112, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/mens/tops/', '', '', '' );

kt_add_menu_item( 2358, $menu_id, 0, 'Scarves', 'product_cat', 100, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/scarves/', '', '', '' );

kt_add_menu_item( 2359, $menu_id, 0, 'T_Shirt', 'product_cat', 108, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/t_shirt/', '', '', '' );

//Menu
$menu_id = kt_add_menu( 164, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 2303, $menu_id, 0, 'Most Populars', 'custom', 2303, 'custom', '#', '', '', '' );

kt_add_menu_item( 2304, $menu_id, 0, 'Best Sellers', 'custom', 2304, 'custom', '#', '', '', '' );

kt_add_menu_item( 2305, $menu_id, 0, 'New Arrivals', 'custom', 2305, 'custom', '#', '', '', '' );

kt_add_menu_item( 2306, $menu_id, 0, 'Special Products', 'custom', 2306, 'custom', '#', '', '', '' );

kt_add_menu_item( 2307, $menu_id, 0, 'Manufacturers', 'custom', 2307, 'custom', '#', '', '', '' );

kt_add_menu_item( 2308, $menu_id, 0, 'Our Stores', 'custom', 2308, 'custom', '#', '', '', '' );

kt_add_menu_item( 2309, $menu_id, 0, 'Shipping', 'custom', 2309, 'custom', '#', '', '', '' );

kt_add_menu_item( 2310, $menu_id, 0, 'Payments', 'custom', 2310, 'custom', '#', '', '', '' );

kt_add_menu_item( 2311, $menu_id, 0, 'Payments', 'custom', 2311, 'custom', '#', '', '', '' );

kt_add_menu_item( 2312, $menu_id, 0, 'Refunds', 'custom', 2312, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 165, 'My account', '' );

 // Menu Item
kt_add_menu_item( 2290, $menu_id, 0, 'My Order', 'custom', 2290, 'custom', '#', '', '', '' );

kt_add_menu_item( 2291, $menu_id, 0, 'My Wishlist', 'custom', 2291, 'custom', '#', '', '', '' );

kt_add_menu_item( 2292, $menu_id, 0, 'My Credit Slip', 'custom', 2292, 'custom', '#', '', '', '' );

kt_add_menu_item( 2293, $menu_id, 0, 'My Addresses', 'custom', 2293, 'custom', '#', '', '', '' );

kt_add_menu_item( 2294, $menu_id, 0, 'My Personal In', 'custom', 2294, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 168, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 2296, $menu_id, 0, 'Online Shopping', 'custom', 2296, 'custom', '#', '', '', '' );

kt_add_menu_item( 2297, $menu_id, 0, 'Promotions', 'custom', 2297, 'custom', '#', '', '', '' );

kt_add_menu_item( 2298, $menu_id, 0, 'My Orders', 'custom', 2298, 'custom', '#', '', '', '' );

kt_add_menu_item( 2299, $menu_id, 0, 'Help', 'custom', 2299, 'custom', '#', '', '', '' );

kt_add_menu_item( 2300, $menu_id, 0, 'Site Map', 'custom', 2300, 'custom', '#', '', '', '' );

kt_add_menu_item( 2301, $menu_id, 0, 'Customer Service', 'custom', 2301, 'custom', '#', '', '', '' );

kt_add_menu_item( 2302, $menu_id, 0, 'Support', 'custom', 2302, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 170, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 2266, $menu_id, 0, 'Salad', 'custom', 2266, 'custom', '#', '', '', '' );

kt_add_menu_item( 2267, $menu_id, 0, 'Paste', 'custom', 2267, 'custom', '#', '', '', '' );

kt_add_menu_item( 2268, $menu_id, 0, 'Tops', 'custom', 2268, 'custom', '#', '', '', '' );

kt_add_menu_item( 2269, $menu_id, 0, 'Tops', 'custom', 2269, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 171, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 2245, $menu_id, 0, 'Meat Dishes', 'custom', 2245, 'custom', '#', '', '', '' );

kt_add_menu_item( 2246, $menu_id, 0, 'Desserts', 'custom', 2246, 'custom', '#', '', '', '' );

kt_add_menu_item( 2261, $menu_id, 0, 'Tops', 'custom', 2261, 'custom', '#', '', '', '' );

kt_add_menu_item( 2262, $menu_id, 0, 'Tops', 'custom', 2262, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 173, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 2337, $menu_id, 0, 'Tennis', 'custom', 2337, 'custom', '#', '', '', '' );

kt_add_menu_item( 2338, $menu_id, 0, 'Coats & Jackets', 'custom', 2338, 'custom', '#', '', '', '' );

kt_add_menu_item( 2339, $menu_id, 0, 'Blouses & Shirts', 'custom', 2339, 'custom', '#', '', '', '' );

kt_add_menu_item( 2340, $menu_id, 0, 'Tops & Tees', 'custom', 2340, 'custom', '#', '', '', '' );

kt_add_menu_item( 2341, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 2341, 'custom', '#', '', '', '' );

kt_add_menu_item( 2342, $menu_id, 0, 'Intimates', 'custom', 2342, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 174, 'Support', '' );

 // Menu Item
kt_add_menu_item( 2280, $menu_id, 0, 'About us', 'custom', 2280, 'custom', '#', '', '', '' );

kt_add_menu_item( 2281, $menu_id, 0, 'Testimonials', 'custom', 2281, 'custom', '#', '', '', '' );

kt_add_menu_item( 2282, $menu_id, 0, 'Affiliate Program', 'custom', 2282, 'custom', '#', '', '', '' );

kt_add_menu_item( 2283, $menu_id, 0, 'Terms & Conditions', 'custom', 2283, 'custom', '#', '', '', '' );

kt_add_menu_item( 2284, $menu_id, 0, 'Contact Us', 'custom', 2284, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 175, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 2313, $menu_id, 0, 'Terms & Conditions', 'custom', 2313, 'custom', '#', '', '', '' );

kt_add_menu_item( 2314, $menu_id, 0, 'Policy', 'custom', 2314, 'custom', '#', '', '', '' );

kt_add_menu_item( 2315, $menu_id, 0, 'Policy', 'custom', 2315, 'custom', '#', '', '', '' );

kt_add_menu_item( 2316, $menu_id, 0, 'Shipping', 'custom', 2316, 'custom', '#', '', '', '' );

kt_add_menu_item( 2317, $menu_id, 0, 'Payments', 'custom', 2317, 'custom', '#', '', '', '' );

kt_add_menu_item( 2318, $menu_id, 0, 'Returns', 'custom', 2318, 'custom', '#', '', '', '' );

kt_add_menu_item( 2319, $menu_id, 0, 'Refunds', 'custom', 2319, 'custom', '#', '', '', '' );

kt_add_menu_item( 2320, $menu_id, 0, 'Warrantee', 'custom', 2320, 'custom', '#', '', '', '' );

kt_add_menu_item( 2321, $menu_id, 0, 'FAQ', 'custom', 2321, 'custom', '#', '', '', '' );

kt_add_menu_item( 2322, $menu_id, 0, 'Contact', 'custom', 2322, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 193, 'Topbar menu left', 'topbar_menuleft' );

 // Menu Item
kt_add_menu_item( 2589, $menu_id, 0, '<i class=\"fa fa-phone\"></i> +00 123 456 789', 'custom', 2589, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2590, $menu_id, 0, '<i class=\"fa fa-envelope\"></i> Contact us today !', 'custom', 2590, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 194, 'Topbar menu right', 'topbar_menuright' );

 // Menu Item
kt_add_menu_item( 2591, $menu_id, 0, 'Support', 'page', 371, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option4/support/', '', '0', '' );

kt_add_menu_item( 2592, $menu_id, 0, 'Services', 'page', 369, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option4/services/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 176, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 2238, $menu_id, 0, 'Men\'s Clothing', 'custom', 2238, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2239, $menu_id, 0, 'Kid\'s Clothing', 'custom', 2239, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2240, $menu_id, 0, 'Women\'s Clothing', 'custom', 2240, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2241, $menu_id, 0, 'Accessories', 'custom', 2241, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/product-category/fashion/', '', '0', '' );
