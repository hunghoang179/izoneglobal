<?php
kt_download_media(2706, 'ads-banner', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/ads-banner.jpg');

kt_download_media(2712, 'bg25.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/bg25.png');

kt_download_media(2713, 'phone.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/phone.png');

kt_download_media(2714, 'headphone.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/headphone.png');

kt_download_media(2715, 'headphone2.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/headphone2.png');

kt_download_media(2716, 'headphone3.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/headphone3.png');
