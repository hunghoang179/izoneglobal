<?php
kt_download_media(2098, 'sport1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/sport1.jpg');

kt_download_media(2099, 'm7', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m7.jpg');

kt_download_media(2100, 'm8', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m8.jpg');

kt_download_media(2101, 'm5', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m5.jpg');

kt_download_media(2102, 'm6', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m6.jpg');

kt_download_media(2103, 'm3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m3.jpg');
