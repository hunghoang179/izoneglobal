<?php
kt_download_media(1883, 's4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/s4.png');

kt_download_media(2004, 'E2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/E2.jpg');

kt_download_media(2005, 'E1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/E1.jpg');
