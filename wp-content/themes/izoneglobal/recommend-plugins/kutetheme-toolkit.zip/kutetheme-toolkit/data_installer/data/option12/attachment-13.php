<?php
kt_download_media(2138, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/banner-topmenu.jpg');

kt_download_media(2140, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/banner-megamenu.jpg');

kt_download_media(2163, 'payment', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/payment.jpg');

kt_download_media(2165, 'bg-box-women', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/bg-box-women.png');

kt_download_media(2166, 'bg-box-men', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/bg-box-men.png');

kt_download_media(2167, 'bg-box-acc', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/bg-box-acc1.png');
