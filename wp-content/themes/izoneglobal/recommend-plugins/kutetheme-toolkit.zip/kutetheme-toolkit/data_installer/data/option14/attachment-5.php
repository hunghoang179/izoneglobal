<?php
kt_download_media(2030, '77', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/77.jpg');

kt_download_media(2031, '78', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/78.jpg');

kt_download_media(2032, '79', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/79.jpg');
