<?php
kt_download_media(2140, 'i 39', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-39.jpg');

kt_download_media(2141, 'i 40', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-40.jpg');

kt_download_media(2142, 'i 38', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-38.jpg');

kt_download_media(2144, 'i 34', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-34.jpg');

kt_download_media(2145, 'i 35', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-35.jpg');
