<?php
kt_download_media(1477, 'digital', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/digital.jpg');

kt_download_media(1478, 'cat-br3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/cat-br3.png');

kt_download_media(1479, 'furniture', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/furniture1.jpg');

kt_download_media(1480, 'jewelry', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/jewelry.jpg');

kt_download_media(1515, 'icon-sports', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-sports1.png');
