<?php
kt_download_media(2060, '416sirti-cut-out-elbiseli7629', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/416sirti-cut-out-elbiseli7629.jpg');

kt_download_media(2061, '4578pilili-elbise2125', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4578pilili-elbise2125.jpg');

kt_download_media(2062, '4578pilili-elbise4514', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4578pilili-elbise4514.jpg');

kt_download_media(2063, '4578pilili-elbise7485', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4578pilili-elbise7485.jpg');
