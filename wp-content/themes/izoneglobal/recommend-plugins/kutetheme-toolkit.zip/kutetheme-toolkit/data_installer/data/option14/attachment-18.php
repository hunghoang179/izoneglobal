<?php
kt_download_media(2138, 'bg-hotdeal', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/bg-hotdeal.jpg');

kt_download_media(2144, 'brand1', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand1.jpg');

kt_download_media(2145, 'brand2', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand2.jpg');