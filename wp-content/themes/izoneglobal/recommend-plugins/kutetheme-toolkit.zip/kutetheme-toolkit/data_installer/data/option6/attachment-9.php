<?php
kt_download_media(1174, 'xxl-20x20', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/xxl-20x20.png');

kt_download_media(1175, 'size-chart-234x350', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/size-chart-234x350.jpg');

kt_download_media(1223, 'O2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/O21.jpg');

kt_download_media(1224, 'O4', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/O4.jpg');

kt_download_media(1231, 'O1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/O11.jpg');

kt_download_media(1262, 'U2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/U22.jpg');
