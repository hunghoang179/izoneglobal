<?php
kt_download_media(1223, 'O2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/O21.jpg');

kt_download_media(1224, 'O4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/O4.jpg');

kt_download_media(1231, 'O1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/O11.jpg');

kt_download_media(1232, 'E1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/E12.jpg');

kt_download_media(1233, 'F2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/F23.jpg');

kt_download_media(1234, 'F3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/F31.jpg');
