<?php
// Custom term
kt_add_category( 174, '1.6 pixel', '1-6-pixel', 'pa_pixel', '0', '' );

kt_add_category( 169, '10 kilogram', '10-kilogram', 'pa_weight', '0', '' );

kt_add_category( 175, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 171, '21 inch', '21-inch', 'pa_inch', '0', '' );

kt_add_category( 172, '29 inch', '29-inch', 'pa_inch', '0', '' );

kt_add_category( 176, '3 liter', '3-liter', 'pa_liter', '0', '' );

kt_add_category( 160, '35', '35', 'pa_size', '0', '' );

kt_add_category( 161, '36', '36', 'pa_size', '0', '' );

kt_add_category( 173, '42 inch', '42-inch', 'pa_inch', '0', '' );

kt_add_category( 168, '5 kilogram', '5-kilogram', 'pa_weight', '0', '' );

kt_add_category( 177, '5 liter', '5-liter', 'pa_liter', '0', '' );

kt_add_category( 170, '7 kilogram', '7-kilogram', 'pa_weight', '0', '' );

kt_add_category( 11, 'active', 'active', 'product_tag', '0', '' );

kt_add_category( 12, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 13, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 14, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 15, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 16, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 144, 'Black', 'black', 'pa_color', '0', '' );

kt_add_category( 184, 'black', 'black', 'pa_weight', '0', '' );

kt_add_category( 145, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 185, 'blue', 'blue', 'pa_weight', '0', '' );

kt_add_category( 152, 'Brown', 'brown', 'pa_color', '0', '' );

kt_add_category( 186, 'brown', 'brown', 'pa_weight', '0', '' );

kt_add_category( 17, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 18, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 19, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 195, 'Channel', 'channel', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_category( 20, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 21, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 22, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 23, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_brand( 197, 'Dejourte', 'dejourte', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_category( 163, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 162, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 146, 'Gray', 'gray', 'pa_color', '0', '' );

kt_add_category( 187, 'gray', 'gray', 'pa_weight', '0', '' );

kt_add_category( 147, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 194, 'Gucci', 'gucci', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_brand( 24, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 199, 'Kiano', 'kiano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_brand( 198, 'Lack', 'lack', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_category( 25, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 26, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 196, 'Luxury', 'luxury', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_category( 153, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 27, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 166, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 28, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 29, 'moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 30, 'new', 'new', 'product_tag', '0', '' );

kt_add_brand( 31, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 32, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 167, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 33, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 150, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 34, 'playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 35, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 36, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 149, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 37, 'Ruby', 'ruby', 'product_tag', '0', '' );

kt_add_category( 155, 'S', 's', 'pa_size', '0', '' );

kt_add_brand( 200, 'Samsang', 'samsang', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '0' );

kt_add_category( 38, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 39, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 164, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 40, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 41, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 42, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 151, 'Violet', 'violet', 'pa_color', '0', '' );

kt_add_category( 43, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 44, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 45, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 165, 'Wood', 'wood', 'pa_material', '0', '' );

kt_add_category( 154, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 156, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 157, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 158, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 159, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 148, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_category( 188, 'yellow', 'yellow', 'pa_weight', '0', '' );

kt_add_product_cat( 189, 'Auto Access', 'auto-access', 'product_cat', '0', '', '0' );

kt_add_product_cat( 46, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 47, 'Electronic', 'electronic', 'product_cat', '0', '', '' );

kt_add_product_cat( 48, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 49, 'Flashlights &amp; Lamps', 'flashlights-lamps', 'product_cat', '47', '', '' );

kt_add_product_cat( 50, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 51, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 52, 'Headphone, Headset', 'headphone-headset-electronic', 'product_cat', '47', '', '' );

kt_add_product_cat( 106, 'Health &amp; Beauty', 'health-beauty', 'product_cat', '48', '', '0' );

kt_add_product_cat( 53, 'Health &amp; Beauty Bags', 'health-beauty-bags', 'product_cat', '48', '', '' );

kt_add_product_cat( 54, 'Home Audio', 'home-audio-electronic', 'product_cat', '47', '', '' );

kt_add_product_cat( 217, 'Home Storage', 'home-storage', 'product_cat', '51', '', '0' );

kt_add_product_cat( 221, 'Home Style', 'home-style', 'product_cat', '51', '', '0' );

kt_add_product_cat( 243, 'Ipad Air', 'ipad-air', 'product_cat', '46', '', '0' );

kt_add_product_cat( 238, 'Jean', 'jean', 'product_cat', '48', '', '0' );

kt_add_product_cat( 55, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 56, 'Jewelry &amp; Watches', 'jewelry-watches', 'product_cat', '55', '', '' );

kt_add_product_cat( 57, 'Kid\'s', 'kids', 'product_cat', '48', '', '' );

kt_add_product_cat( 218, 'Kitchen Tools', 'kitchen-tools', 'product_cat', '51', '', '0' );

kt_add_product_cat( 58, 'Laptop', 'laptop', 'product_cat', '46', '', '' );

kt_add_product_cat( 219, 'Livingroom', 'livingroom', 'product_cat', '51', '', '0' );

kt_add_product_cat( 59, 'Loveseats', 'loveseats', 'product_cat', '51', '', '' );

kt_add_product_cat( 242, 'Memory Card', 'memory-card', 'product_cat', '46', '', '0' );

kt_add_product_cat( 60, 'Men Watches', 'men-watches', 'product_cat', '55', '', '0' );

kt_add_product_cat( 61, 'Men\'s', 'mens', 'product_cat', '48', '', '' );

kt_add_product_cat( 62, 'Mobile', 'mobile', 'product_cat', '46', '', '' );

kt_add_product_cat( 191, 'Modern Active', 'modern-active', 'product_cat', '48', '', '0' );

kt_add_product_cat( 63, 'Mp3 Player', 'mp3-player-accessories-electronic', 'product_cat', '47', '', '' );

kt_add_product_cat( 64, 'Necklaces', 'necklaces', 'product_cat', '55', '', '0' );

kt_add_product_cat( 214, 'Networking', 'networking', 'product_cat', '46', '', '0' );

kt_add_product_cat( 65, 'Notebook', 'notebook', 'product_cat', '46', '', '' );

kt_add_product_cat( 66, 'Office Furniture', 'office-furniture', 'product_cat', '51', '', '' );

kt_add_product_cat( 220, 'Painting', 'painting', 'product_cat', '51', '', '0' );

kt_add_product_cat( 67, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '55', '', '' );

kt_add_product_cat( 211, 'Printer Supplies', 'printer-supplies', 'product_cat', '46', '', '0' );

kt_add_product_cat( 68, 'Scarves', 'scarves', 'product_cat', '48', '', '' );

kt_add_product_cat( 69, 'Shoes &amp; Accessories', 'shoes-accessories', 'product_cat', '48', '', '' );

kt_add_product_cat( 70, 'Skirts', 'skirts', 'product_cat', '61', '', '' );

kt_add_product_cat( 71, 'Smartphone &amp; Tablets', 'smartphone-tablets', 'product_cat', '46', '', '' );

kt_add_product_cat( 206, 'SOOCOO S60', 'soocoo-s60', 'product_cat', '47', '', '0' );

kt_add_product_cat( 207, 'Speaker', 'speaker', 'product_cat', '47', '', '0' );

kt_add_product_cat( 73, 'Sports', 'sports', 'product_cat', '0', '', '0' );

kt_add_product_cat( 190, 'Style Fashion', 'style-fashion', 'product_cat', '48', '', '0' );

kt_add_product_cat( 74, 'Swimming', 'swimming', 'product_cat', '73', '', '' );

kt_add_product_cat( 75, 'T_Shirt', 't_shirt', 'product_cat', '48', '', '' );

kt_add_product_cat( 76, 'Television', 'television-2', 'product_cat', '46', '', '' );

kt_add_product_cat( 208, 'Television', 'television', 'product_cat', '47', '', '0' );

kt_add_product_cat( 77, 'Tennis', 'tennis', 'product_cat', '73', '', '' );

kt_add_product_cat( 78, 'Theater', 'theater', 'product_cat', '47', '', '' );

kt_add_product_cat( 79, 'Tops', 'tops', 'product_cat', '61', '', '' );

kt_add_product_cat( 80, 'Toys &amp; Hobbies', 'toys-hobbies', 'product_cat', '0', '', '' );

kt_add_product_cat( 193, 'Traditional Style', 'traditional-style', 'product_cat', '48', '', '0' );

kt_add_product_cat( 201, 'Traveling Suplies', 'traveling-suplies', 'product_cat', '73', '', '0' );

kt_add_product_cat( 81, 'Trending', 'trending', 'product_cat', '48', '', '' );

kt_add_product_cat( 202, 'Volleyball', 'volleyball', 'product_cat', '73', '', '0' );

kt_add_product_cat( 239, 'Walking', 'walking', 'product_cat', '73', '', '0' );

kt_add_product_cat( 245, 'Wall Painting', 'wall-painting', 'product_cat', '51', '', '0' );

kt_add_product_cat( 241, 'Washing Machine', 'washing-machine', 'product_cat', '47', '', '0' );

kt_add_product_cat( 83, 'Wedding Rings', 'wedding-rings', 'product_cat', '55', '', '0' );

kt_add_product_cat( 84, 'Women\'s', 'womens', 'product_cat', '48', '', '' );

kt_add_product_cat( 246, '925 Silver', '925-silver', 'product_cat', '55', '', '0' );

kt_add_product_cat( 85, 'Accessories', 'accessories', 'product_cat', '55', '', '' );

kt_add_product_cat( 86, 'Accessories for iPad', 'accessories-for-ipad', 'product_cat', '46', '', '' );

kt_add_product_cat( 87, 'Accessories for iPhone', 'accessories-for-iphone', 'product_cat', '46', '', '' );

kt_add_product_cat( 88, 'Accessories for Tablet', 'accessories-for-tablet-pc', 'product_cat', '46', '', '' );

kt_add_product_cat( 89, 'Air Conditional', 'air-conditional', 'product_cat', '47', '', '' );

kt_add_product_cat( 90, 'ARM', 'arm', 'product_cat', '47', '', '' );

kt_add_product_cat( 209, 'Auto Machine', 'auto-machine', 'product_cat', '47', '', '0' );

kt_add_product_cat( 203, 'Basketball', 'basketball', 'product_cat', '73', '', '0' );

kt_add_product_cat( 91, 'Batteries &amp; Chargers', 'batteries-chargers-electronic', 'product_cat', '47', '', '' );

kt_add_product_cat( 92, 'Bedding', 'bedding', 'product_cat', '51', '', '' );

kt_add_product_cat( 244, 'Bedding Room', 'bedding-room', 'product_cat', '51', '', '0' );

kt_add_product_cat( 222, 'Body Chains', 'body-chains', 'product_cat', '55', '', '0' );

kt_add_product_cat( 225, 'Body Piercing', 'body-piercing', 'product_cat', '55', '', '0' );

kt_add_product_cat( 93, 'Camera', 'camera', 'product_cat', '46', '', '' );

kt_add_product_cat( 94, 'Cameras &amp; Photo', 'cameras-photo', 'product_cat', '46', '', '' );

kt_add_product_cat( 95, 'Camping &amp; Hiking', 'camping-hiking', 'product_cat', '73', '', '0' );

kt_add_product_cat( 192, 'Casual', 'casual', 'product_cat', '48', '', '0' );

kt_add_product_cat( 96, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '51', '', '' );

kt_add_product_cat( 224, 'Championship Rings', 'championship-rings', 'product_cat', '55', '', '0' );

kt_add_product_cat( 97, 'Climbing', 'climbing', 'product_cat', '73', '', '' );

kt_add_product_cat( 210, 'Compact Device', 'compact-device', 'product_cat', '47', '', '0' );

kt_add_product_cat( 98, 'Computers', 'computers-networking', 'product_cat', '46', '', '' );

kt_add_product_cat( 240, 'Cooker', 'cooker', 'product_cat', '47', '', '0' );

kt_add_product_cat( 212, 'Cooking Tools', 'cooking-tools', 'product_cat', '51', '', '0' );

kt_add_product_cat( 213, 'Cross Stitch', 'cross-stitch', 'product_cat', '51', '', '0' );

kt_add_product_cat( 215, 'Curtain', 'curtain', 'product_cat', '51', '', '0' );

kt_add_product_cat( 216, 'Decorative', 'decorative', 'product_cat', '51', '', '0' );

kt_add_product_cat( 99, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '55', '', '' );

kt_add_product_cat( 223, 'Digital Watches', 'digital-watches', 'product_cat', '55', '', '0' );

kt_add_product_cat( 237, 'Dress', 'dress', 'product_cat', '48', '', '0' );

kt_add_product_cat( 100, 'Earring', 'earring', 'product_cat', '55', '', '0' );

kt_add_product_cat( 247, 'Engagement Rings', 'engagement-rings', 'product_cat', '55', '', '0' );

kt_add_product_cat( 101, 'Fishing', 'fishing', 'product_cat', '73', '', '0' );

kt_add_product_cat( 205, 'Fitness', 'fitness', 'product_cat', '73', '', '0' );

kt_add_product_cat( 102, 'Football', 'football', 'product_cat', '73', '', '' );

kt_add_product_cat( 104, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '55', '', '' );

kt_add_product_cat( 105, 'Golf Supplies', 'golf-supplies', 'product_cat', '73', '', '0' );

kt_add_product_cat( 204, 'Hiking Shoes', 'hiking-shoes', 'product_cat', '73', '', '0' );

kt_add_product_cat( 108, 'Jackets', 'jackets', 'product_cat', '61', '', '' );

kt_add_product_cat( 109, 'Outdoor Supplies', 'outdoor-traveling-supplies', 'product_cat', '73', '', '0' );

kt_add_product_cat( 72, 'Sport &amp; Outdoors', 'sport-outdoor', 'product_cat', '73', '', '0' );
