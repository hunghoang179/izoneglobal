<?php
//Menu
$menu_id = kt_add_menu( 60, 'Vertical Menu', '' );

 // Menu Item
kt_add_menu_item( 893, $menu_id, 0, 'Electronic', 'custom', 893, 'custom', '#', '', '', '' );

kt_add_menu_item( 894, $menu_id, 0, 'Sport & Outdoors', 'custom', 894, 'custom', '#', '', '', '' );

kt_add_menu_item( 895, $menu_id, 0, 'Smartphone & Tablets', 'custom', 895, 'custom', '#', '', '', '' );

kt_add_menu_item( 896, $menu_id, 0, 'Health & Beauty Bags', 'custom', 896, 'custom', '#', '', '', '' );

kt_add_menu_item( 897, $menu_id, 0, 'Shoes & Accessories', 'custom', 897, 'custom', '#', '', '', '' );

kt_add_menu_item( 898, $menu_id, 0, 'Toy & Hobbies', 'custom', 898, 'custom', '#', '', '', '' );

kt_add_menu_item( 899, $menu_id, 0, 'Television', 'custom', 899, 'custom', '#', '', '', '' );

kt_add_menu_item( 900, $menu_id, 0, 'Fashion', 'custom', 900, 'custom', '#', '', '', '' );

kt_add_menu_item( 901, $menu_id, 0, 'Furniture', 'custom', 901, 'custom', '#', '', '', '' );

kt_add_menu_item( 902, $menu_id, 0, 'Health & Beauty', 'custom', 902, 'custom', '#', '', '', '' );
