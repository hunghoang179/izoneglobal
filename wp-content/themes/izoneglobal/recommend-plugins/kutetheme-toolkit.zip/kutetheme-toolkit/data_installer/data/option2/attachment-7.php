<?php
kt_download_media(1286, 'S1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/S12.jpg');

kt_download_media(1287, 'K2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/K21.jpg');

kt_download_media(1297, 'K1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/K11.jpg');

kt_download_media(1307, 'J1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/J12.jpg');

kt_download_media(1308, 'J2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/J21.jpg');

kt_download_media(2064, '2.jpg', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/revslider/slider2/2.jpg');
