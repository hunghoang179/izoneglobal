<?php
kt_download_media(2149, 'slide-left', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/slide-left.jpg');

kt_download_media(2150, 'slide-left2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/slide-left2.jpg');

kt_download_media(2153, 'bg14.png', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/revslider/kute-opt13/bg14.png');

kt_download_media(2154, 'bg23.png', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/revslider/kute-opt13/bg23.png');

kt_download_media(2155, 's1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/s1.jpg');

kt_download_media(2156, 's2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/s2.jpg');
