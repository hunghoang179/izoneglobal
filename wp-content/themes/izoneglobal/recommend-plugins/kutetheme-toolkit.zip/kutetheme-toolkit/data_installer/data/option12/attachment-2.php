<?php
kt_download_media(2013, '12', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/12.jpg');

kt_download_media(2014, '7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/7.jpg');

kt_download_media(2015, '8', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/8.jpg');

kt_download_media(2016, '9', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/9.jpg');

kt_download_media(2017, '10', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2018, '11', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/11.jpg');

kt_download_media(2021, '13', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/13.jpg');
