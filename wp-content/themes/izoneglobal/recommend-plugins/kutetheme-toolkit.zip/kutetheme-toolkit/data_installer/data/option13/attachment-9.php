<?php
kt_download_media(2091, '6', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/6.png');

kt_download_media(2092, '7', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/7.png');

kt_download_media(2093, '8', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/8.png');

kt_download_media(2094, '9', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/9.png');

kt_download_media(2095, '10', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/10.png');

kt_download_media(2096, '11', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/11.png');

kt_download_media(2103, 'new-icon', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/new-icon.png');
