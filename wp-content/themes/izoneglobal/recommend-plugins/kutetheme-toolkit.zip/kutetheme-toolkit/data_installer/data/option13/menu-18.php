<?php
//Menu
$menu_id = kt_add_menu( 179, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 1906, $menu_id, 0, 'Salad', 'custom', 1906, 'custom', '#', '', '', '' );

kt_add_menu_item( 1907, $menu_id, 0, 'Paste', 'custom', 1907, 'custom', '#', '', '', '' );

kt_add_menu_item( 1908, $menu_id, 0, 'Tops', 'custom', 1908, 'custom', '#', '', '', '' );

kt_add_menu_item( 1909, $menu_id, 0, 'Tops', 'custom', 1909, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 180, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 1886, $menu_id, 0, 'Meat Dishes', 'custom', 1886, 'custom', '#', '', '', '' );

kt_add_menu_item( 1887, $menu_id, 0, 'Desserts', 'custom', 1887, 'custom', '#', '', '', '' );

kt_add_menu_item( 1901, $menu_id, 0, 'Tops', 'custom', 1901, 'custom', '#', '', '', '' );

kt_add_menu_item( 1902, $menu_id, 0, 'Tops', 'custom', 1902, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 182, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 1977, $menu_id, 0, 'Tennis', 'custom', 1977, 'custom', '#', '', '', '' );

kt_add_menu_item( 1978, $menu_id, 0, 'Coats & Jackets', 'custom', 1978, 'custom', '#', '', '', '' );

kt_add_menu_item( 1979, $menu_id, 0, 'Blouses & Shirts', 'custom', 1979, 'custom', '#', '', '', '' );

kt_add_menu_item( 1980, $menu_id, 0, 'Tops & Tees', 'custom', 1980, 'custom', '#', '', '', '' );

kt_add_menu_item( 1981, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 1981, 'custom', '#', '', '', '' );

kt_add_menu_item( 1982, $menu_id, 0, 'Intimates', 'custom', 1982, 'custom', '#', '', '', '' );
