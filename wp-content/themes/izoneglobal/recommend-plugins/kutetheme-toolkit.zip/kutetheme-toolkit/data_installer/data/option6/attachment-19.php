<?php
kt_download_media(2018, 'p60', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p60.jpg');

kt_download_media(2020, 'p65', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p65.jpg');

kt_download_media(2021, 'p86', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p86.jpg');

kt_download_media(2022, 'p81', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p81.jpg');

kt_download_media(2023, 'p83', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p83.jpg');

kt_download_media(2024, 'p84', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p84.jpg');

kt_download_media(2025, 'p82', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p82.jpg');
