<?php
kt_download_media(2066, 'b6', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b6.jpg');

kt_download_media(2068, 'b7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b7.jpg');

kt_download_media(2069, 'b8', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b8.jpg');

kt_download_media(2079, 'testimonial1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/testimonial1.png');

kt_download_media(2080, 'testimonial3', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/testimonial3.png');

kt_download_media(2081, 'testimonial2', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/testimonial2.png');

kt_download_media(2085, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog1.jpg');
