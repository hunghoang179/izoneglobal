<?php
kt_download_media(2282, 'icon-digital', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-digital.png');

kt_download_media(2283, 'icon-fashion', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-fashion.png');

kt_download_media(2284, 'icon-electronic', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-electronic.png');

kt_download_media(2285, 'icon-jewelry', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-jewelry.png');

kt_download_media(2286, 'icon-furniture', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-furniture.png');