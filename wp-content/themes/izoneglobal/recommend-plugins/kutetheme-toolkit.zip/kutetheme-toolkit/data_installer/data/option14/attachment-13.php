<?php
kt_download_media(2093, 'slide-left2', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/slide-left2.jpg');

kt_download_media(2098, 'men', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/men.png');

kt_download_media(2099, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/kid.png');
