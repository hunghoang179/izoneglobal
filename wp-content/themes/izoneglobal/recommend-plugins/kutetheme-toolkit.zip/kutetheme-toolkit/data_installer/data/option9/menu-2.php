<?php
//Menu
$menu_id = kt_add_menu( 54, 'footer CUSTOMER SERVICE', '' );

 // Menu Item
kt_add_menu_item( 921, $menu_id, 0, 'Advanced Search', 'custom', 921, 'custom', '#', '', '', '' );

kt_add_menu_item( 922, $menu_id, 0, 'Orders and Returns', 'custom', 922, 'custom', '#', '', '', '' );

kt_add_menu_item( 923, $menu_id, 0, 'Contact Us', 'custom', 923, 'custom', '#', '', '', '' );

kt_add_menu_item( 924, $menu_id, 0, 'RSS', 'custom', 924, 'custom', '#', '', '', '' );

kt_add_menu_item( 925, $menu_id, 0, 'Help & FAQs', 'custom', 925, 'custom', '#', '', '', '' );

kt_add_menu_item( 928, $menu_id, 0, 'Consultant', 'custom', 928, 'custom', '#', '', '', '' );

kt_add_menu_item( 929, $menu_id, 0, 'Store Locations', 'custom', 929, 'custom', '#', '', '', '' );
