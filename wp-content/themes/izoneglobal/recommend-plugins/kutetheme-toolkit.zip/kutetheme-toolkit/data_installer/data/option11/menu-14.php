<?php
//Menu
$menu_id = kt_add_menu( 19, 'Vertical Menu', 'vertical' );

 // Menu Item
kt_add_menu_item( 25, $menu_id, 0, 'Electronic', 'custom', 25, 'custom', '#', '', '0', '38' );

kt_add_menu_item( 58, $menu_id, 0, 'Sport & Outdoors', 'custom', 58, 'custom', '#', 'enabled', '766', '39' );

kt_add_menu_item( 59, $menu_id, 0, 'Smartphone & Tablets', 'custom', 59, 'custom', '#', '', '0', '40' );

kt_add_menu_item( 60, $menu_id, 0, 'Health & Beauty Bags', 'custom', 60, 'custom', '#', 'enabled', '764', '41' );

kt_add_menu_item( 61, $menu_id, 0, 'Shoes & Accessories', 'custom', 61, 'custom', '#', '', '764', '42' );

kt_add_menu_item( 62, $menu_id, 0, 'Toy & Hobbies', 'custom', 62, 'custom', '#', '', '0', '43' );

kt_add_menu_item( 63, $menu_id, 0, 'Television', 'custom', 63, 'custom', '#', '', '0', '48' );

kt_add_menu_item( 64, $menu_id, 0, 'Fashion', 'custom', 64, 'custom', '#', '', '0', '44' );

kt_add_menu_item( 65, $menu_id, 0, 'Furniture', 'custom', 65, 'custom', '#', '', '0', '45' );

kt_add_menu_item( 66, $menu_id, 0, 'Health & Beauty', 'custom', 66, 'custom', '#', '', '0', '46' );

