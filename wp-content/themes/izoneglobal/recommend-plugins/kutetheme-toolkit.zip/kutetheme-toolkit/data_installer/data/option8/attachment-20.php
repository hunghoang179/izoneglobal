<?php
kt_download_media(2140, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/banner-topmenu.jpg');

kt_download_media(2156, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/logo.png');

kt_download_media(2163, 'bg1.png', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/revslider/kute-opt8/bg1.png');

kt_download_media(2164, 'bg2.png', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/revslider/kute-opt8/bg2.png');