<?php
kt_download_media(2068, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog411.jpg');

kt_download_media(2085, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog61.jpg');

kt_download_media(2086, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog71.jpg');
