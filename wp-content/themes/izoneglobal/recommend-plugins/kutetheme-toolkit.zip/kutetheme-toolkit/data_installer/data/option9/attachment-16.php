<?php
kt_download_media(941, 'bg1.jpg', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/revslider/kute-opt9/bg1.jpg');

kt_download_media(942, 'bg2.jpg', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/revslider/kute-opt9/bg2.jpg');

kt_download_media(943, 'bg3.jpg', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/revslider/kute-opt9/bg3.jpg');

kt_download_media(945, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/logo1.png');

kt_download_media(947, 'service-bg', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/service-bg.jpg');

kt_download_media(952, 'payment-logo', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/payment-logo.png');
