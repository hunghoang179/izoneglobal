<?php
kt_download_media(1309, 'J3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/J31.jpg');

kt_download_media(1310, 'J5', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/J5.jpg');

kt_download_media(1313, 'S2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/S21.jpg');

kt_download_media(1314, 'S3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/S31.jpg');

kt_download_media(1315, 'S5', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/S5.jpg');

kt_download_media(1325, 'R2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/R21.jpg');

kt_download_media(1326, 'R3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/R31.jpg');
