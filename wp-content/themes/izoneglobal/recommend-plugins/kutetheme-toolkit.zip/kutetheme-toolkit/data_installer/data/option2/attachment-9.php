<?php
kt_download_media(2071, 'ld9', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld9.jpg');

kt_download_media(2072, 'p44', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p44.jpg');

kt_download_media(2073, 'p88', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p88.jpg');

kt_download_media(2075, 'p86', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p86.jpg');

kt_download_media(2077, 'p83', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p83.jpg');

kt_download_media(2078, 'p84', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p84.jpg');
