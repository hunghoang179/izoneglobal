<?php
kt_download_media(1168, '61', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/61.jpg');

kt_download_media(1175, 'size-chart-234x350', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/size-chart-234x350.jpg');

kt_download_media(1182, 'H4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/H4.jpg');

kt_download_media(1183, 'H1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/H13.jpg');

kt_download_media(1184, 'H3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/H3.jpg');

kt_download_media(1194, 'P1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/P12.jpg');

kt_download_media(1195, 'C1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/C12.jpg');

kt_download_media(1196, 'D3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/D3.jpg');
