<?php
//Menu
$menu_id = kt_add_menu( 180, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 1337, $menu_id, 0, 'Vietnamese Pho', 'custom', 1337, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1338, $menu_id, 0, 'Noodles', 'custom', 1338, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1339, $menu_id, 0, 'Seafood', 'custom', 1339, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 181, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 1418, $menu_id, 0, 'Electronic', 'product_cat', 68, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/electronic/', '', '0', '1016' );

kt_add_menu_item( 1419, $menu_id, 0, 'Sport & Outdoors', 'product_cat', 115, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/sport-outdoor/', 'enabled', '589', '1017' );

kt_add_menu_item( 1420, $menu_id, 0, 'Smartphone & Tablets', 'product_cat', 112, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/smartphone-tablets/', '', '0', '1018' );

kt_add_menu_item( 1422, $menu_id, 0, 'Health & Beauty Bags', 'product_cat', 77, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/health-beauty-bags/', '', '0', '1019' );

kt_add_menu_item( 1421, $menu_id, 0, 'Shoes & Accessories', 'product_cat', 109, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/shoes-accessories/', 'enabled', '764', '1020' );

kt_add_menu_item( 1423, $menu_id, 0, 'Computers & Networking', 'product_cat', 66, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/computers-networking/', '', '0', '1022' );

kt_add_menu_item( 1426, $menu_id, 0, 'Laptops & Accessories', 'product_cat', 87, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/laptops-accessories/', '', '0', '1018' );

kt_add_menu_item( 1424, $menu_id, 0, 'Jewelry & Watches', 'product_cat', 82, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/jewelry/jewelry-watches/', '', '0', '1024' );

kt_add_menu_item( 1427, $menu_id, 0, 'Flashlights & Lamps', 'product_cat', 71, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/electronic/flashlights-lamps/', '', '0', '1025' );

kt_add_menu_item( 1428, $menu_id, 0, 'Cameras & Photo', 'product_cat', 65, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/cameras-photo/', '', '0', '2007' );

kt_add_menu_item( 1429, $menu_id, 0, 'Television', 'product_cat', 123, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/electronic/television-2/', '', '0', '1016' );

kt_add_menu_item( 1430, $menu_id, 0, 'Fashion', 'product_cat', 70, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '1025' );

kt_add_menu_item( 1431, $menu_id, 0, 'Furniture', 'product_cat', 73, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/furniture/', '', '0', '1016' );

kt_add_menu_item( 1432, $menu_id, 0, 'Health & Beauty', 'product_cat', 76, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/health-beauty/', '', '0', '1019' );

//Menu
$menu_id = kt_add_menu( 182, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 1349, $menu_id, 0, 'Italian Pizza', 'custom', 1349, 'custom', '#', '', '', '' );

kt_add_menu_item( 1350, $menu_id, 0, 'French Cakes', 'custom', 1350, 'custom', '#', '', '', '' );

kt_add_menu_item( 1351, $menu_id, 0, 'Tops', 'custom', 1351, 'custom', '#', '', '', '' );

kt_add_menu_item( 1352, $menu_id, 0, 'Tops', 'custom', 1352, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 183, 'Company', '' );

 // Menu Item
kt_add_menu_item( 1380, $menu_id, 0, 'About Us', 'custom', 1380, 'custom', '#', '', '', '' );

kt_add_menu_item( 1381, $menu_id, 0, 'Testimonials', 'custom', 1381, 'custom', '#', '', '', '' );

kt_add_menu_item( 1382, $menu_id, 0, 'Affiliate Program', 'custom', 1382, 'custom', '#', '', '', '' );

kt_add_menu_item( 1383, $menu_id, 0, 'Terms & Conditions', 'custom', 1383, 'custom', '#', '', '', '' );

kt_add_menu_item( 1384, $menu_id, 0, 'Contact Us', 'custom', 1384, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 184, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 1390, $menu_id, 0, 'Company Info - Partnerships', 'custom', 1390, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 186, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 1364, $menu_id, 0, 'Mobile', 'custom', 1364, 'custom', '#', '', '', '' );

kt_add_menu_item( 1365, $menu_id, 0, 'Tablets', 'custom', 1365, 'custom', '#', '', '', '' );

kt_add_menu_item( 1366, $menu_id, 0, 'Laptop', 'custom', 1366, 'custom', '#', '', '', '' );

kt_add_menu_item( 1367, $menu_id, 0, 'Memory Cards', 'custom', 1367, 'custom', '#', '', '', '' );

kt_add_menu_item( 1368, $menu_id, 0, 'Accessories', 'custom', 1368, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 187, 'euro', '' );

 // Menu Item
kt_add_menu_item( 1342, $menu_id, 0, 'Greek Potatoes', 'custom', 1342, 'custom', '#', '', '', '' );

kt_add_menu_item( 1353, $menu_id, 0, 'Famous Spaghetti', 'custom', 1353, 'custom', '#', '', '', '' );

kt_add_menu_item( 1354, $menu_id, 0, 'Famous Spaghetti', 'custom', 1354, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 188, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 1448, $menu_id, 0, 'Skirts', 'custom', 1448, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/skirts-fashion/', '', '0', '' );

kt_add_menu_item( 1449, $menu_id, 0, 'Jackets', 'custom', 1449, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/jackets-fashion/', '', '0', '' );

kt_add_menu_item( 1450, $menu_id, 0, 'Jumpsuits', 'custom', 1450, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/jumpsuits/', '', '0', '' );

kt_add_menu_item( 1451, $menu_id, 0, 'Scarves', 'custom', 1451, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/scarves-fashion/', '', '0', '' );

kt_add_menu_item( 1452, $menu_id, 0, 'T-Shirts', 'custom', 1452, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/t-shirts/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 189, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 1357, $menu_id, 0, 'Hamberger', 'custom', 1357, 'custom', '#', '', '', '' );

kt_add_menu_item( 1358, $menu_id, 0, 'Pizza', 'custom', 1358, 'custom', '#', '', '', '' );

kt_add_menu_item( 1359, $menu_id, 0, 'Noodles', 'custom', 1359, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 192, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 1439, $menu_id, 0, 'Shoes', 'custom', 1439, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1440, $menu_id, 0, 'Clothing', 'custom', 1440, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1441, $menu_id, 0, 'Tops', 'custom', 1441, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1442, $menu_id, 0, 'Scarves', 'custom', 1442, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1447, $menu_id, 0, 'Accessories', 'custom', 1447, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 193, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 1583, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 1594, $menu_id, 1583, 'Home 1', 'custom', 1594, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1', '', '0', '' );

kt_add_menu_item( 1595, $menu_id, 1583, 'Home 2', 'custom', 1595, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2', '', '0', '' );

kt_add_menu_item( 1979, $menu_id, 1583, 'Home 5', 'custom', 1979, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 1596, $menu_id, 1583, 'Home 6', 'custom', 1596, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6', '', '0', '' );

kt_add_menu_item( 1343, $menu_id, 0, 'Fashion', 'product_cat', 70, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', 'enabled', '23', '' );

kt_add_menu_item( 1344, $menu_id, 0, 'Foods', 'product_cat', 72, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/foods/', 'enabled', '40', '1593' );

kt_add_menu_item( 1345, $menu_id, 0, 'Sports', 'product_cat', 116, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1346, $menu_id, 0, 'Digital', 'product_cat', 67, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/', '', '0', '' );

kt_add_menu_item( 1370, $menu_id, 1346, 'Smartphone & Tablets', 'custom', 1370, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/accessories-for-tablet/', '', '0', '' );

kt_add_menu_item( 1371, $menu_id, 1346, 'Laptop & Accessories', 'custom', 1371, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/laptops-accessories/', '', '0', '' );

kt_add_menu_item( 1372, $menu_id, 1346, 'Camera & Photo', 'custom', 1372, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/cameras-photo/', '', '0', '' );

kt_add_menu_item( 1373, $menu_id, 1346, 'iPhone Accessories', 'custom', 1373, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/accessories-for-iphone/', '', '0', '' );

kt_add_menu_item( 1374, $menu_id, 1346, 'ipad Accessories', 'custom', 1374, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/digital/accessories-for-ipad/', '', '0', '' );

kt_add_menu_item( 1347, $menu_id, 0, 'Furniture', 'product_cat', 73, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 1348, $menu_id, 0, 'Jewelry', 'product_cat', 81, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 1453, $menu_id, 0, 'Blog', 'page', 975, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option6/sample-page-2/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 194, 'Men&#039;s', '' );

 // Menu Item
kt_add_menu_item( 1328, $menu_id, 0, 'Jackets', 'product_cat', 80, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/jackets-fashion/', '', '', '' );

kt_add_menu_item( 1329, $menu_id, 0, 'Pants', 'product_cat', 102, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/mens/pants/', '', '', '' );

kt_add_menu_item( 1330, $menu_id, 0, 'Scarves', 'product_cat', 106, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/mens/scarves/', '', '', '' );

kt_add_menu_item( 1331, $menu_id, 0, 'Skirts', 'product_cat', 110, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/mens/skirts/', '', '', '' );

kt_add_menu_item( 1332, $menu_id, 0, 'Tops', 'product_cat', 126, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/mens/tops/', '', '', '' );

//Menu
$menu_id = kt_add_menu( 195, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 1398, $menu_id, 0, 'Most Populars', 'custom', 1398, 'custom', '#', '', '', '' );

kt_add_menu_item( 1399, $menu_id, 0, 'Best Sellers', 'custom', 1399, 'custom', '#', '', '', '' );

kt_add_menu_item( 1400, $menu_id, 0, 'New Arrivals', 'custom', 1400, 'custom', '#', '', '', '' );

kt_add_menu_item( 1401, $menu_id, 0, 'Special Products', 'custom', 1401, 'custom', '#', '', '', '' );

kt_add_menu_item( 1402, $menu_id, 0, 'Manufacturers', 'custom', 1402, 'custom', '#', '', '', '' );

kt_add_menu_item( 1403, $menu_id, 0, 'Our Stores', 'custom', 1403, 'custom', '#', '', '', '' );

kt_add_menu_item( 1404, $menu_id, 0, 'Shipping', 'custom', 1404, 'custom', '#', '', '', '' );

kt_add_menu_item( 1405, $menu_id, 0, 'Payments', 'custom', 1405, 'custom', '#', '', '', '' );

kt_add_menu_item( 1406, $menu_id, 0, 'Payments', 'custom', 1406, 'custom', '#', '', '', '' );

kt_add_menu_item( 1407, $menu_id, 0, 'Refunds', 'custom', 1407, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 196, 'My account', '' );

 // Menu Item
kt_add_menu_item( 1385, $menu_id, 0, 'My Order', 'custom', 1385, 'custom', '#', '', '', '' );

kt_add_menu_item( 1386, $menu_id, 0, 'My Wishlist', 'custom', 1386, 'custom', '#', '', '', '' );

kt_add_menu_item( 1387, $menu_id, 0, 'My Credit Slip', 'custom', 1387, 'custom', '#', '', '', '' );

kt_add_menu_item( 1388, $menu_id, 0, 'My Addresses', 'custom', 1388, 'custom', '#', '', '', '' );

kt_add_menu_item( 1389, $menu_id, 0, 'My Personal In', 'custom', 1389, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 199, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 1391, $menu_id, 0, 'Online Shopping', 'custom', 1391, 'custom', '#', '', '', '' );

kt_add_menu_item( 1392, $menu_id, 0, 'Promotions', 'custom', 1392, 'custom', '#', '', '', '' );

kt_add_menu_item( 1393, $menu_id, 0, 'My Orders', 'custom', 1393, 'custom', '#', '', '', '' );

kt_add_menu_item( 1394, $menu_id, 0, 'Help', 'custom', 1394, 'custom', '#', '', '', '' );

kt_add_menu_item( 1395, $menu_id, 0, 'Site Map', 'custom', 1395, 'custom', '#', '', '', '' );

kt_add_menu_item( 1396, $menu_id, 0, 'Customer Service', 'custom', 1396, 'custom', '#', '', '', '' );

kt_add_menu_item( 1397, $menu_id, 0, 'Support', 'custom', 1397, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 201, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 1360, $menu_id, 0, 'Salad', 'custom', 1360, 'custom', '#', '', '', '' );

kt_add_menu_item( 1361, $menu_id, 0, 'Paste', 'custom', 1361, 'custom', '#', '', '', '' );

kt_add_menu_item( 1362, $menu_id, 0, 'Tops', 'custom', 1362, 'custom', '#', '', '', '' );

kt_add_menu_item( 1363, $menu_id, 0, 'Tops', 'custom', 1363, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 202, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 1340, $menu_id, 0, 'Meat Dishes', 'custom', 1340, 'custom', '#', '', '', '' );

kt_add_menu_item( 1341, $menu_id, 0, 'Desserts', 'custom', 1341, 'custom', '#', '', '', '' );

kt_add_menu_item( 1355, $menu_id, 0, 'Tops', 'custom', 1355, 'custom', '#', '', '', '' );

kt_add_menu_item( 1356, $menu_id, 0, 'Tops', 'custom', 1356, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 204, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 1433, $menu_id, 0, 'Tennis', 'custom', 1433, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1434, $menu_id, 0, 'Coats & Jackets', 'custom', 1434, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1435, $menu_id, 0, 'Blouses & Shirts', 'custom', 1435, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1436, $menu_id, 0, 'Tops & Tees', 'custom', 1436, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1437, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 1437, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1438, $menu_id, 0, 'Intimates', 'custom', 1438, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/sports/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 205, 'Support', '' );

 // Menu Item
kt_add_menu_item( 1375, $menu_id, 0, 'About us', 'custom', 1375, 'custom', '#', '', '', '' );

kt_add_menu_item( 1376, $menu_id, 0, 'Testimonials', 'custom', 1376, 'custom', '#', '', '', '' );

kt_add_menu_item( 1377, $menu_id, 0, 'Affiliate Program', 'custom', 1377, 'custom', '#', '', '', '' );

kt_add_menu_item( 1378, $menu_id, 0, 'Terms & Conditions', 'custom', 1378, 'custom', '#', '', '', '' );

kt_add_menu_item( 1379, $menu_id, 0, 'Contact Us', 'custom', 1379, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 206, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 1408, $menu_id, 0, 'Terms & Conditions', 'custom', 1408, 'custom', '#', '', '', '' );

kt_add_menu_item( 1409, $menu_id, 0, 'Policy', 'custom', 1409, 'custom', '#', '', '', '' );

kt_add_menu_item( 1410, $menu_id, 0, 'Policy', 'custom', 1410, 'custom', '#', '', '', '' );

kt_add_menu_item( 1411, $menu_id, 0, 'Shipping', 'custom', 1411, 'custom', '#', '', '', '' );

kt_add_menu_item( 1412, $menu_id, 0, 'Payments', 'custom', 1412, 'custom', '#', '', '', '' );

kt_add_menu_item( 1413, $menu_id, 0, 'Returns', 'custom', 1413, 'custom', '#', '', '', '' );

kt_add_menu_item( 1414, $menu_id, 0, 'Refunds', 'custom', 1414, 'custom', '#', '', '', '' );

kt_add_menu_item( 1415, $menu_id, 0, 'Warrantee', 'custom', 1415, 'custom', '#', '', '', '' );

kt_add_menu_item( 1416, $menu_id, 0, 'FAQ', 'custom', 1416, 'custom', '#', '', '', '' );

kt_add_menu_item( 1417, $menu_id, 0, 'Contact', 'custom', 1417, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 239, 'Topbar menu left', 'topbar_menuleft' );

 // Menu Item
kt_add_menu_item( 1987, $menu_id, 0, '<i class=\"fa fa-phone\"></i> +00 123 456 789', 'custom', 1987, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1988, $menu_id, 0, '<i class=\"fa fa-envelope\"></i> Contact us today !', 'custom', 1988, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 240, 'Topbar menu right', 'topbar_menuright' );

 // Menu Item
kt_add_menu_item( 1989, $menu_id, 0, 'Support', 'page', 371, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option6/support/', '', '0', '' );

kt_add_menu_item( 1990, $menu_id, 0, 'Services', 'page', 369, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option6/services/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 207, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 1333, $menu_id, 0, 'Men\'s Clothing', 'custom', 1333, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1334, $menu_id, 0, 'Kid\'s Clothing', 'custom', 1334, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1335, $menu_id, 0, 'Women\'s Clothing', 'custom', 1335, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1336, $menu_id, 0, 'Accessories', 'custom', 1336, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/product-category/fashion/', '', '0', '' );


