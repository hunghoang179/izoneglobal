<?php
kt_download_media(2136, 'trademark-fe', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-fe.jpg');

kt_download_media(2137, 'trademark-mc', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-mc.jpg');

kt_download_media(2138, 'trademark-qiwi', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-qiwi.jpg');

kt_download_media(2139, 'trademark-ups', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-ups.jpg');

kt_download_media(2140, 'trademark-visa', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-visa.jpg');

kt_download_media(2141, 'trademark-wm', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-wm.jpg');
