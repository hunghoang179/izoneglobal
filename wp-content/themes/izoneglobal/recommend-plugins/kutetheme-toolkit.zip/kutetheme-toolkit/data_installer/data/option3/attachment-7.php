<?php
kt_download_media(2043, 'S5', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/S5.jpg');

kt_download_media(2044, 'U2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/U2.jpg');

kt_download_media(2045, 'U3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/U3.jpg');

kt_download_media(2046, 'U6', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/U6.jpg');

kt_download_media(2047, 'H2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/H2.jpg');

kt_download_media(2048, 'H4', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/H4.jpg');

kt_download_media(2049, 'H1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/H1.jpg');
