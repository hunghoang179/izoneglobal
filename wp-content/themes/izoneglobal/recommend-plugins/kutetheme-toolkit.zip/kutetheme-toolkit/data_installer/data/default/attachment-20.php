<?php

kt_download_media(2107, 'blog31', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2109, 'blog41', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2112, 'trademark-cn', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/trademark-cn.jpg');

kt_download_media(2113, 'testimonial', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/testimonial.jpg');

kt_download_media(2114, 'blog2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog2.jpg');
