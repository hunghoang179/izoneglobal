<?php
//Menu
$menu_id = kt_add_menu( 172, 'Men', '' );

 // Menu Item
kt_add_menu_item( 1868, $menu_id, 0, 'Jackets', 'product_cat', 150, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/mens/jackets/', '', '0', '' );

kt_add_menu_item( 1869, $menu_id, 0, 'Skirts', 'product_cat', 112, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/mens/skirts/', '', '0', '' );

kt_add_menu_item( 1870, $menu_id, 0, 'Tops', 'product_cat', 121, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/mens/tops/', '', '0', '' );

kt_add_menu_item( 1995, $menu_id, 0, 'Scarves', 'product_cat', 110, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/scarves/', '', '0', '' );

kt_add_menu_item( 1996, $menu_id, 0, 'T_Shirt', 'product_cat', 117, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/t_shirt/', '', '0', '' );
