<?php
kt_download_media(2054, 'ads7', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads7.jpg');

kt_download_media(2056, 'ads8', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads8.jpg');

kt_download_media(2057, 'ads9', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads9.jpg');

kt_download_media(2058, 'ads10', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads10.jpg');

kt_download_media(2059, 'ads11', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads11.jpg');
