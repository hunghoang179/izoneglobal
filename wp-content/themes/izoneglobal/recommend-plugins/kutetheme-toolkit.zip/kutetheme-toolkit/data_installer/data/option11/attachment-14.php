<?php
kt_download_media(838, 'band3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band3.png');

kt_download_media(839, 'band4', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band4.png');

kt_download_media(840, 'band5', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band5.png');

kt_download_media(841, 'band6', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band6.png');

kt_download_media(842, 'band7', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band7.png');

kt_download_media(843, 'banner1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner1.jpg');
