<?php

kt_download_media(2081, 'hm2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/hm2.jpg');

kt_download_media(2083, 'banner-topmenu', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/banner-topmenu.jpg');

kt_download_media(2084, 'men', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/men.png');

kt_download_media(2085, 'women', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/women.png');

kt_download_media(2086, 'kid', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/kid.png');
