<?php
kt_download_media(2101, 'women', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/women.png');

kt_download_media(2102, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/trending.png');

kt_download_media(2103, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/banner-topmenu.jpg');
