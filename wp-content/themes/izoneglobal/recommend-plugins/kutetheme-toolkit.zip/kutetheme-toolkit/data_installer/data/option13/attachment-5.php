<?php
kt_download_media(2033, '24', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/24.jpg');

kt_download_media(2037, '29', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/29.jpg');
