<?php
kt_download_media(37, 'cart-icon4', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/cart-icon4.jpg');

kt_download_media(38, '1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/1.png');

kt_download_media(39, '2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/2.png');

kt_download_media(40, '3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/3.png');

kt_download_media(41, '4', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/4.png');

kt_download_media(42, '5', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/5.png');
