<?php
kt_download_media(2050, 'Z3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Z3.jpg');

kt_download_media(2051, 'Z1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Z1.jpg');

kt_download_media(2052, 'Z2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Z2.jpg');

kt_download_media(2053, 'O2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/O2.jpg');

kt_download_media(2054, 'O1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/O1.jpg');

kt_download_media(2055, 'O3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/O3.jpg');

kt_download_media(2056, 'K2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/K2.jpg');
