<?php
kt_download_media(2023, '14', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/14.jpg');

kt_download_media(2024, '15', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/15.jpg');

kt_download_media(2025, '16', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/16.jpg');

kt_download_media(2026, '17', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/17.jpg');

kt_download_media(2028, '20', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/20.jpg');

kt_download_media(2029, '21', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/21.jpg');
