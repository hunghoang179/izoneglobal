<?php
kt_download_media(2233, '11', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/11.jpg');

kt_download_media(2234, '12', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/12.jpg');

kt_download_media(2237, '15', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/15.jpg');

