<?php
kt_download_media(850, 'banner8', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner8.jpg');

kt_download_media(851, 'banner9', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner9.jpg');

kt_download_media(852, 'banner10', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner10.jpg');

kt_download_media(853, 'banner11', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner11.jpg');

kt_download_media(854, 'banner12', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner12.jpg');

kt_download_media(855, 's1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s12.png');
