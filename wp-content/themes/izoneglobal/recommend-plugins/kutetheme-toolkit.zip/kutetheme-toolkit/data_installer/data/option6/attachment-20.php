<?php
kt_download_media(2026, 'p85', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p85.jpg');

kt_download_media(2028, 'icon-digital', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-digital.png');

kt_download_media(2029, 'icon-fashion', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-fashion.png');

kt_download_media(2030, 'icon-electronic', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-electronic.png');

kt_download_media(2031, 'icon-jewelry', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-jewelry.png');

kt_download_media(2032, 'icon-furniture', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-furniture.png');

kt_download_media(2033, 'icon-sports', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-sports.png');
