<?php
//Menu
$menu_id = kt_add_menu( 158, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 1140, $menu_id, 0, 'Most Populars', 'custom', 1140, 'custom', '#', '', '', '' );

kt_add_menu_item( 1141, $menu_id, 0, 'Best Sellers', 'custom', 1141, 'custom', '#', '', '', '' );

kt_add_menu_item( 1142, $menu_id, 0, 'New Arrivals', 'custom', 1142, 'custom', '#', '', '', '' );

kt_add_menu_item( 1143, $menu_id, 0, 'Special Products', 'custom', 1143, 'custom', '#', '', '', '' );

kt_add_menu_item( 1144, $menu_id, 0, 'Manufacturers', 'custom', 1144, 'custom', '#', '', '', '' );

kt_add_menu_item( 1145, $menu_id, 0, 'Our Stores', 'custom', 1145, 'custom', '#', '', '', '' );

kt_add_menu_item( 1146, $menu_id, 0, 'Shipping', 'custom', 1146, 'custom', '#', '', '', '' );

kt_add_menu_item( 1147, $menu_id, 0, 'Payments', 'custom', 1147, 'custom', '#', '', '', '' );

kt_add_menu_item( 1148, $menu_id, 0, 'Payments', 'custom', 1148, 'custom', '#', '', '', '' );

kt_add_menu_item( 1149, $menu_id, 0, 'Refunds', 'custom', 1149, 'custom', '#', '', '', '' );
