<?php

//Menu
$menu_id = kt_add_menu( 53, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 903, $menu_id, 0, 'Jackets', 'custom', 903, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 904, $menu_id, 0, 'Skirt', 'custom', 904, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 905, $menu_id, 0, 'Casual', 'custom', 905, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 906, $menu_id, 0, 'Tops', 'custom', 906, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 907, $menu_id, 0, 'Scarves', 'custom', 907, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 908, $menu_id, 0, 'T- Shirts', 'custom', 908, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );
