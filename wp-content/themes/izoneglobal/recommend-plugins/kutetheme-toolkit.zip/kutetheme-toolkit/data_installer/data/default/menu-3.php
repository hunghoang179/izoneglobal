<?php
//Menu
$menu_id = kt_add_menu( 159, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 1895, $menu_id, 0, 'Italian Pizza', 'custom', 1895, 'custom', '#', '', '', '' );

kt_add_menu_item( 1896, $menu_id, 0, 'French Cakes', 'custom', 1896, 'custom', '#', '', '', '' );

kt_add_menu_item( 1897, $menu_id, 0, 'Tops', 'custom', 1897, 'custom', '#', '', '', '' );

kt_add_menu_item( 1898, $menu_id, 0, 'Tops', 'custom', 1898, 'custom', '#', '', '', '' );
