<?php
kt_download_media(2396, '2.jpg', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/slider2/2.jpg');

kt_download_media(2397, '11.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/slider2/11.png');

kt_download_media(2398, '2.21.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/slider2/2.21.png');

kt_download_media(2399, '32.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/slider2/32.png');

kt_download_media(2400, 'line3.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/slider2/line3.png');

kt_download_media(2405, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b1.jpg');
