<?php
kt_download_media(2121, '6', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/6.png');

kt_download_media(2122, '7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/7.png');

kt_download_media(2123, '8', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/8.png');

kt_download_media(2124, '9', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/9.png');

kt_download_media(2125, '10', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/10.png');
