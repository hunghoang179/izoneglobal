<?php
kt_download_media(2017, 'R4', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/R4.jpg');

kt_download_media(2018, 'R5', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/R5.jpg');

kt_download_media(2019, 'P2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/P2.jpg');

kt_download_media(2020, 'P1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/P1.jpg');

kt_download_media(2021, 'P3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/P3.jpg');

kt_download_media(2022, 'I2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/I2.jpg');

kt_download_media(2023, 'I1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/I1.jpg');

kt_download_media(2024, 'I3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/I3.jpg');
