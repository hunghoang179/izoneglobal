<?php
kt_download_media(1204, 'A1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/A11.jpg');

kt_download_media(1205, 'I2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/I22.jpg');

kt_download_media(1206, 'I5', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/I5.jpg');

kt_download_media(1213, 'I1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/I11.jpg');

kt_download_media(1214, 'C3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/C3.jpg');

kt_download_media(1215, 'D1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/D12.jpg');

kt_download_media(1222, 'B1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/B11.jpg');
