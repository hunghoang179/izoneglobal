<?php
// Attachment
kt_download_media(2173, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/logo.png');

kt_download_media(2174, 'logo2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/logo2.png');
