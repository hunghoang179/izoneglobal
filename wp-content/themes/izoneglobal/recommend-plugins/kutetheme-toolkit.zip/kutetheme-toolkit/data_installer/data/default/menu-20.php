<?php
//Menu
$menu_id = kt_add_menu( 185, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 1871, $menu_id, 0, 'Men\'s Clothing', 'custom', 1871, 'custom', '#', '', '', '' );

kt_add_menu_item( 1872, $menu_id, 0, 'Kid\'s Clothing', 'custom', 1872, 'custom', '#', '', '', '' );

kt_add_menu_item( 1873, $menu_id, 0, 'Women\'s Clothing', 'custom', 1873, 'custom', '#', '', '', '' );

kt_add_menu_item( 1874, $menu_id, 0, 'Accessories', 'custom', 1874, 'custom', '#', '', '', '' );

