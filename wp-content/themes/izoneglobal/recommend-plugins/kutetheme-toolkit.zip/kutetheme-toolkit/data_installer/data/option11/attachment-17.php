<?php

kt_download_media(856, 's2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s22.png');

kt_download_media(857, 's3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s32.png');

kt_download_media(861, 'paralax11', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/paralax11.jpg');

kt_download_media(873, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/kid.png');

kt_download_media(874, 'men', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/men.png');

kt_download_media(875, 'women', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/women.png');
