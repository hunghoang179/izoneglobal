<?php
// Custom term
kt_add_category( 234, '1.6 pixel', '1-6-pixel', 'pa_pixel', '0', '' );

kt_add_category( 230, '10 kilogram', '10-kilogram', 'pa_weight', '0', '' );

kt_add_category( 236, '14 inch', '14-inch', 'pa_inch', '0', '' );

kt_add_category( 231, '2 liter', '2-liter', 'pa_liter', '0', '' );

kt_add_category( 235, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 237, '21 inch', '21-inch', 'pa_inch', '0', '' );

kt_add_category( 232, '3 liter', '3-liter', 'pa_liter', '0', '' );

kt_add_category( 238, '32 inch', '32-inch', 'pa_inch', '0', '' );

kt_add_category( 224, '34', '34', 'pa_size', '0', '' );

kt_add_category( 225, '35', '35', 'pa_size', '0', '' );

kt_add_category( 226, '36', '36', 'pa_size', '0', '' );

kt_add_category( 227, '37', '37', 'pa_size', '0', '' );

kt_add_category( 228, '5 kilogram', '5-kilogram', 'pa_weight', '0', '' );

kt_add_category( 233, '5 liter', '5-liter', 'pa_liter', '0', '' );

kt_add_category( 229, '7 kilogram', '7-kilogram', 'pa_weight', '0', '' );

kt_add_category( 11, 'Active', 'active', 'product_tag', '0', '' );

kt_add_category( 12, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 13, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 14, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 15, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 16, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 17, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 18, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 19, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 20, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 21, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 22, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 23, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 24, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_category( 25, 'cute', 'cute', 'product_tag', '0', '' );

kt_add_category( 26, 'Dark Brown', 'dark-brown', 'pa_color', '0', '' );

kt_add_category( 216, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 217, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 27, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 28, 'Grey', 'grey', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 29, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 30, 'Light Blue', 'light-blue', 'pa_color', '0', '' );

kt_add_category( 31, 'Light Brown', 'light-brown', 'pa_color', '0', '' );

kt_add_category( 32, 'Light Pink', 'light-pink', 'pa_color', '0', '' );

kt_add_category( 33, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 34, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 35, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 36, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 37, 'Maroon', 'maroon', 'pa_color', '0', '' );

kt_add_category( 219, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 38, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 39, 'Moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 40, 'new', 'new', 'product_tag', '0', '' );

kt_add_category( 41, 'Orange', 'orange', 'pa_color', '0', '' );

kt_add_brand( 42, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 43, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 218, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 44, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 45, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 220, 'Plastic', 'plastic', 'pa_material', '0', '' );

kt_add_category( 46, 'Playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 47, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 48, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 49, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 221, 'Ruby', 'ruby', 'pa_material', '0', '' );

kt_add_category( 50, 'S', 's', 'pa_size', '0', '' );

kt_add_category( 51, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 52, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 222, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 53, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 54, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 55, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 56, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 57, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 58, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 223, 'Wood', 'wood', 'pa_material', '0', '' );

kt_add_category( 59, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 60, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 61, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 62, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 63, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 64, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_product_cat( 67, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 68, 'Electronic', 'electronic', 'product_cat', '0', '', '' );

kt_add_product_cat( 70, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 71, 'Flashlights &amp; Lamps', 'flashlights-lamps', 'product_cat', '68', '', '0' );

kt_add_product_cat( 72, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 73, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 74, 'Hair Accessories', 'hair-accessories', 'product_cat', '70', '', '' );

kt_add_product_cat( 75, 'Headphone, Headset', 'headphone-headset-electronic', 'product_cat', '68', '', '' );

kt_add_product_cat( 76, 'Health &amp; Beauty', 'health-beauty', 'product_cat', '70', '', '1518' );

kt_add_product_cat( 77, 'Health &amp; Beauty Bags', 'health-beauty-bags', 'product_cat', '70', '', '0' );

kt_add_product_cat( 78, 'Home Audio', 'home-audio-electronic', 'product_cat', '68', '', '' );

kt_add_product_cat( 79, 'Home Storage', 'home-storage', 'product_cat', '73', '', '' );

kt_add_product_cat( 80, 'Jackets', 'jackets-fashion', 'product_cat', '70', '', '' );

kt_add_product_cat( 81, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 82, 'Jewelry &amp; Watches', 'jewelry-watches', 'product_cat', '81', '', '1522' );

kt_add_product_cat( 83, 'Jumpsuits', 'jumpsuits', 'product_cat', '70', '', '' );

kt_add_product_cat( 84, 'Kid\'s', 'kids', 'product_cat', '70', '', '' );

kt_add_product_cat( 85, 'Kitchen Tools', 'kitchen-tools', 'product_cat', '73', '', '' );

kt_add_product_cat( 87, 'Laptops &amp; Accessories', 'laptops-accessories', 'product_cat', '67', '', '0' );

kt_add_product_cat( 88, 'Livingroom', 'livingroom', 'product_cat', '73', '', '' );

kt_add_product_cat( 89, 'Loveseats', 'loveseats', 'product_cat', '73', '', '' );

kt_add_product_cat( 90, 'Men Watches', 'men-watches', 'product_cat', '82', '', '' );

kt_add_product_cat( 91, 'Men\'s', 'mens', 'product_cat', '70', '', '' );

kt_add_product_cat( 92, 'Men\'s Watches', 'mens-watches', 'product_cat', '81', '', '' );

kt_add_product_cat( 96, 'Necklaces', 'necklaces', 'product_cat', '82', '', '' );

kt_add_product_cat( 97, 'Necklaces', 'necklaces-jewelry', 'product_cat', '81', '', '' );

kt_add_product_cat( 99, 'Office Furniture', 'office-furniture', 'product_cat', '73', '', '' );

kt_add_product_cat( 101, 'Painting', 'painting', 'product_cat', '73', '', '' );

kt_add_product_cat( 102, 'Pants', 'pants', 'product_cat', '91', '', '' );

kt_add_product_cat( 103, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '81', '', '' );

kt_add_product_cat( 105, 'Salon &amp; Spa', 'salon-spa-equipment', 'product_cat', '76', '', '' );

kt_add_product_cat( 106, 'Scarves', 'scarves', 'product_cat', '91', '', '' );

kt_add_product_cat( 107, 'Scarves', 'scarves-fashion', 'product_cat', '70', '', '' );

kt_add_product_cat( 108, 'Shaving &amp; Hair', 'shaving-hair-removal', 'product_cat', '76', '', '' );

kt_add_product_cat( 109, 'Shoes &amp; Accessories', 'shoes-accessories', 'product_cat', '70', '', '1520' );

kt_add_product_cat( 110, 'Skirts', 'skirts', 'product_cat', '91', '', '' );

kt_add_product_cat( 111, 'Skirts', 'skirts-fashion', 'product_cat', '70', '', '' );

kt_add_product_cat( 112, 'Smartphone &amp; Tablets', 'smartphone-tablets', 'product_cat', '67', '', '0' );

kt_add_product_cat( 113, 'SOOCOO S60', 'soocoo-s60', 'product_cat', '68', '', '' );

kt_add_product_cat( 114, 'Speaker', 'speaker', 'product_cat', '68', '', '' );

kt_add_product_cat( 116, 'Sports', 'sports', 'product_cat', '0', '', '0' );

kt_add_product_cat( 119, 'Sunglasses', 'sunglasses-sports', 'product_cat', '116', '', '' );

kt_add_product_cat( 120, 'Surfing', 'surfing', 'product_cat', '116', '', '' );

kt_add_product_cat( 121, 'T-Shirts', 't-shirts', 'product_cat', '70', '', '' );

kt_add_product_cat( 123, 'Television', 'television-2', 'product_cat', '68', '', '0' );

kt_add_product_cat( 124, 'Tennis', 'tennis', 'product_cat', '116', '', '' );

kt_add_product_cat( 126, 'Tops', 'tops', 'product_cat', '91', '', '' );

kt_add_product_cat( 210, 'Tops', 'tops-shoes-accessories', 'product_cat', '109', '', '0' );

kt_add_product_cat( 128, 'Trending', 'trending', 'product_cat', '70', '', '' );

kt_add_product_cat( 130, 'Wedding Rings', 'wedding-rings', 'product_cat', '82', '', '' );

kt_add_product_cat( 131, 'Wedding rings', 'wedding-rings-jewelry', 'product_cat', '81', '', '' );

kt_add_product_cat( 132, 'Women\'s', 'womens', 'product_cat', '70', '', '' );

kt_add_product_cat( 133, '925 Silver', '925-silver', 'product_cat', '81', '', '' );

kt_add_product_cat( 134, 'Accessories', 'accessories', 'product_cat', '81', '', '' );

kt_add_product_cat( 135, 'Accessories for iPad', 'accessories-for-ipad', 'product_cat', '67', '', '' );

kt_add_product_cat( 136, 'Accessories for iPhone', 'accessories-for-iphone', 'product_cat', '67', '', '' );

kt_add_product_cat( 137, 'Accessories for Tablet', 'accessories-for-tablet', 'product_cat', '67', '', '' );

kt_add_product_cat( 138, 'Air Conditional', 'air-conditional', 'product_cat', '68', '', '' );

kt_add_product_cat( 139, 'ARM', 'arm', 'product_cat', '68', '', '' );

kt_add_product_cat( 140, 'Basketball Shoes', 'basketball-shoes', 'product_cat', '116', '', '' );

kt_add_product_cat( 141, 'Bath &amp; Body', 'bath-body', 'product_cat', '76', '', '' );

kt_add_product_cat( 142, 'Batteries &amp; Chargers', 'batteries-chargers-electronic', 'product_cat', '68', '', '' );

kt_add_product_cat( 143, 'Bedding', 'bedding', 'product_cat', '73', '', '' );

kt_add_product_cat( 144, 'Bike Light', 'bike-light', 'product_cat', '116', '', '' );

kt_add_product_cat( 147, 'Body Chains', 'body-chains', 'product_cat', '81', '', '' );

kt_add_product_cat( 211, 'Bottoms', 'bottoms', 'product_cat', '109', '', '0' );

kt_add_product_cat( 213, 'Bottoms', 'bottoms-health-beauty', 'product_cat', '76', '', '0' );

kt_add_product_cat( 214, 'Bottoms', 'bottoms-jewelry-watches', 'product_cat', '82', '', '0' );

kt_add_product_cat( 149, 'Boxing', 'boxing', 'product_cat', '116', '', '' );

kt_add_product_cat( 151, 'Camera', 'camera-electronic', 'product_cat', '68', '', '' );

kt_add_product_cat( 65, 'Cameras &amp; Photo', 'cameras-photo', 'product_cat', '67', '', '0' );

kt_add_product_cat( 153, 'Camping Stoves', 'camping-stoves', 'product_cat', '116', '', '' );

kt_add_product_cat( 155, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '73', '', '' );

kt_add_product_cat( 156, 'Championship rings', 'championship-rings', 'product_cat', '81', '', '' );

kt_add_product_cat( 157, 'Climbing', 'climbing', 'product_cat', '116', '', '' );

kt_add_product_cat( 66, 'Computers &amp; Networking', 'computers-networking', 'product_cat', '67', '', '0' );

kt_add_product_cat( 158, 'Cooking Tools', 'cooking-tools', 'product_cat', '73', '', '' );

kt_add_product_cat( 159, 'Cross Stitch', 'cross-stitch', 'product_cat', '73', '', '' );

kt_add_product_cat( 160, 'Curtain', 'curtain', 'product_cat', '73', '', '' );

kt_add_product_cat( 161, 'Cycling Jerseys', 'cycling-jerseys', 'product_cat', '116', '', '' );

kt_add_product_cat( 162, 'Decorative', 'decorative', 'product_cat', '73', '', '' );

kt_add_product_cat( 163, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '81', '', '' );

kt_add_product_cat( 164, 'Digital Watches', 'digital-watches', 'product_cat', '81', '', '' );

kt_add_product_cat( 165, 'Dress Watches', 'dress-watches', 'product_cat', '81', '', '' );

kt_add_product_cat( 166, 'Earring', 'earring', 'product_cat', '82', '', '' );

kt_add_product_cat( 69, 'Engagement Rings', 'engagement-rings', 'product_cat', '81', '', '0' );

kt_add_product_cat( 168, 'Fishing Tackle Bags', 'fishing-tackle-bags', 'product_cat', '116', '', '' );

kt_add_product_cat( 169, 'Fitness', 'fitness', 'product_cat', '116', '', '' );

kt_add_product_cat( 170, 'Football', 'football', 'product_cat', '116', '', '' );

kt_add_product_cat( 172, 'Fragrances', 'fragrances', 'product_cat', '76', '', '' );

kt_add_product_cat( 212, 'Glasses', 'glasses', 'product_cat', '109', '', '0' );

kt_add_product_cat( 173, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '81', '', '' );

kt_add_product_cat( 176, 'Hiking Shoes', 'hiking-shoes', 'product_cat', '116', '', '' );

kt_add_product_cat( 177, 'Keepfit', 'keepfit', 'product_cat', '116', '', '' );

kt_add_product_cat( 209, 'Leather Bags', 'leather-bags', 'product_cat', '109', '', '0' );

kt_add_product_cat( 208, 'Shoes', 'shoes', 'product_cat', '109', '', '0' );

kt_add_product_cat( 115, 'Sport &amp; Outdoors', 'sport-outdoor', 'product_cat', '116', '', '0' );

kt_add_product_cat( 152, 'Camping &amp; Hiking', 'camping-hiking', 'product_cat', '115', '', '' );

kt_add_product_cat( 167, 'Fishing', 'fishing', 'product_cat', '115', '', '' );

kt_add_product_cat( 174, 'Golf Supplies', 'golf-supplies', 'product_cat', '115', '', '' );

kt_add_product_cat( 178, 'Outdoor &amp; Traveling Supplies', 'outdoor-traveling-supplies', 'product_cat', '115', '', '' );

