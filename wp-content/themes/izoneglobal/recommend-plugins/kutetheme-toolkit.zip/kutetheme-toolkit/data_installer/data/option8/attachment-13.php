<?php
kt_download_media(2081, 'nt_21133.8561431990131', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_21133.8561431990131.jpg');

kt_download_media(2083, '41060324_37', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/41060324_37.jpg');

kt_download_media(2084, '41060324_37_R', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/41060324_37_R.jpg');

kt_download_media(2085, '43043622_56', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/43043622_56.jpg');
