<?php
kt_download_media(2247, '1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/1.jpg');

kt_download_media(2248, 'bg11.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/bg11.png');

kt_download_media(2249, 'trademark1.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/trademark1.png');

kt_download_media(2250, 'line1.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/line1.png');

kt_download_media(2251, 'line2.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/line2.png');
