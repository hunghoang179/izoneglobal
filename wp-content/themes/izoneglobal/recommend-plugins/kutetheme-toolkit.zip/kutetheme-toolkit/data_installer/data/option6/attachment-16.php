<?php
kt_download_media(1593, 'icon-new', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/icon-new.png');

kt_download_media(1597, 'A1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/A12.jpg');

kt_download_media(1598, 'A2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/A21.jpg');

kt_download_media(1599, 'A3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/A3.jpg');

kt_download_media(1960, '11', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/111.jpg');

kt_download_media(1961, 'i 39', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-39.jpg');

kt_download_media(1962, 'i 40', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-40.jpg');
