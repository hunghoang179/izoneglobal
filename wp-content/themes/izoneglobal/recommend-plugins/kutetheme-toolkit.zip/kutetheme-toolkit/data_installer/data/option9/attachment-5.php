<?php
kt_download_media(110, '27', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/27.jpg');

kt_download_media(111, '29 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/29-Copy.jpg');

kt_download_media(112, '30 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/30-Copy.jpg');

kt_download_media(115, '3', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/3.jpg');

kt_download_media(116, '32 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/32-Copy.jpg');
