<?php
kt_download_media(2667, 'men', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/men.png');

kt_download_media(2669, 'women', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/women.png');

kt_download_media(2670, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/kid.png');

kt_download_media(2671, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/trending.png');

kt_download_media(2672, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog2.jpg');

kt_download_media(2684, 'payment', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/payment.png');
