<?php
kt_download_media(2406, 'b2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b2.jpg');

kt_download_media(2500, '51', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/51.jpg');

kt_download_media(2501, '52', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/52.jpg');

kt_download_media(2502, '53', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/53.jpg');

kt_download_media(2503, '54', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/54.jpg');

kt_download_media(2504, '55', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/55.jpg');
