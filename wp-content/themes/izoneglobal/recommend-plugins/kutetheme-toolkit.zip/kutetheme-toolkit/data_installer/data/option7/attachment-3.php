<?php
kt_download_media(2240, '3', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/3.jpg');

kt_download_media(2241, '3---Copy', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/3-Copy.jpg');

kt_download_media(2242, '4', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/4.jpg');

kt_download_media(2243, '5', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/5.jpg');

kt_download_media(2244, '6', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/6.jpg');
