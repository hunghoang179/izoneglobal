<?php
//Menu
$menu_id = kt_add_menu( 160, 'Company', '' );

 // Menu Item
kt_add_menu_item( 1925, $menu_id, 0, 'About Us', 'custom', 1925, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1926, $menu_id, 0, 'Testimonials', 'custom', 1926, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1927, $menu_id, 0, 'Affiliate Program', 'custom', 1927, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1928, $menu_id, 0, 'Terms & Conditions', 'custom', 1928, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1929, $menu_id, 0, 'Contact Us', 'custom', 1929, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2254, $menu_id, 0, 'Manufactures', 'custom', 2254, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2255, $menu_id, 0, 'Blog', 'custom', 2255, 'custom', '#', '', '0', '' );
