<?php
kt_download_media(2057, 'K1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/K1.jpg');

kt_download_media(2058, 'K3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/K3.jpg');

kt_download_media(2059, 'A2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/A2.jpg');

kt_download_media(2060, 'A1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/A1.jpg');

kt_download_media(2061, 'A3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/A3.jpg');

kt_download_media(2062, '20', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/20.jpeg');

kt_download_media(2063, '15', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/15.jpg');

kt_download_media(2064, '16', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/16.jpg');
