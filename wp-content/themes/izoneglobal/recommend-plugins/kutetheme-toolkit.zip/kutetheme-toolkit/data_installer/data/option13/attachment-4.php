<?php

kt_download_media(2007, '5', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/5.jpg');

kt_download_media(2008, '6', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/6.jpg');
