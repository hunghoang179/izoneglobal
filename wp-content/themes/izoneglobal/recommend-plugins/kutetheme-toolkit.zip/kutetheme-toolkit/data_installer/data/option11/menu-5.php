<?php
//Menu
$menu_id = kt_add_menu( 65, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 898, $menu_id, 0, 'Hamberger', 'custom', 898, 'custom', '#', '', '0', '' );

kt_add_menu_item( 899, $menu_id, 0, 'Pizza', 'custom', 899, 'custom', '#', '', '0', '' );

kt_add_menu_item( 900, $menu_id, 0, 'Noodles', 'custom', 900, 'custom', '#', '', '0', '' );
