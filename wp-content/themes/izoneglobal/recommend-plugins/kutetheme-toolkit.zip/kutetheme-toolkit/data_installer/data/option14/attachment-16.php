<?php
kt_download_media(2123, 'bg24.png', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/revslider/kute-opt14/bg24.png');

kt_download_media(2125, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/b1.jpg');

kt_download_media(2126, 'b2', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/b2.jpg');
