<?php
kt_download_media(2110, 'banner-bottom2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-bottom2.jpg');

kt_download_media(2112, 'p54', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p54.jpg');

kt_download_media(2113, 'p57', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p57.jpg');

kt_download_media(2114, 'p58', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p58.jpg');

kt_download_media(2115, 'p56', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p56.jpg');

kt_download_media(2116, 'p55', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p55.jpg');
