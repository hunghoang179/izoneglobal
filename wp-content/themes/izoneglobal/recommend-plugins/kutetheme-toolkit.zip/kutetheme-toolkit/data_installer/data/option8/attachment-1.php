<?php
// Attachment
kt_download_media(1823, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/banner2.png');

kt_download_media(1840, 'banner3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/banner3.png');

kt_download_media(1859, 'megamenu', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/10/megamenu.png');

kt_download_media(1862, 'megamenu2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/10/megamenu2.png');

kt_download_media(2006, 'slider1.jpg', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/revslider/slide-8/slider1.jpg');

kt_download_media(2007, 'slider2.jpg', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/revslider/slide-8/slider2.jpg');

kt_download_media(2018, 'loock-boock', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/loock-boock.jpg');

