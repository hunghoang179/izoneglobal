<?php
kt_download_media(2269, 'p11', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p11.jpg');

kt_download_media(2270, 'p85', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p85.jpg');

kt_download_media(2271, 'p86', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p86.jpg');

kt_download_media(2272, 'icon-s1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s1.png');

kt_download_media(2273, 'icon-s2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s2.png');
