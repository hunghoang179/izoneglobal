<?php
kt_download_media(2401, 'bg23.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/bg23.png');

kt_download_media(2402, '50.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/50.png');

kt_download_media(2403, 'shop2.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/shop2.png');

kt_download_media(2404, 'phantram.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/phantram.png');

kt_download_media(2405, 'off.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/off.png');

kt_download_media(2406, 'line31.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/line31.png');

kt_download_media(2407, 'bg31.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/bg31.png');

kt_download_media(2408, 'shopnow.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/shopnow.png');
