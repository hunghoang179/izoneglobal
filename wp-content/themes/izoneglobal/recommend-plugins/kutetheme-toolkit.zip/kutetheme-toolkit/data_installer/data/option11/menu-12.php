<?php
//Menu
$menu_id = kt_add_menu( 47, 'Sport1', '' );

 // Menu Item
kt_add_menu_item( 181, $menu_id, 0, 'Tennis', 'custom', 181, 'custom', '#', '', '', '' );

kt_add_menu_item( 182, $menu_id, 0, 'Football', 'custom', 182, 'custom', '#', '', '', '' );

kt_add_menu_item( 183, $menu_id, 0, 'Swimming', 'custom', 183, 'custom', '#', '', '', '' );

kt_add_menu_item( 184, $menu_id, 0, 'Basketballs', 'custom', 184, 'custom', '#', '', '', '' );

kt_add_menu_item( 185, $menu_id, 0, 'Volleyball', 'custom', 185, 'custom', '#', '', '', '' );
