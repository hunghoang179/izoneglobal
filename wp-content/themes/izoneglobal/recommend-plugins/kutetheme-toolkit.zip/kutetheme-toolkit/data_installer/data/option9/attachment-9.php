<?php
kt_download_media(146, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog8.jpg');

kt_download_media(147, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog11.jpg');

kt_download_media(148, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog22.jpg');

kt_download_media(149, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog31.jpg');

kt_download_media(150, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog41.jpg');
