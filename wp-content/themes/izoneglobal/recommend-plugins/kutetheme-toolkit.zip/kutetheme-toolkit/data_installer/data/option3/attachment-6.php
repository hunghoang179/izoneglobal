<?php
kt_download_media(2035, 'J2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/J2.jpg');

kt_download_media(2036, 'J3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/J3.jpg');

kt_download_media(2037, 'J5', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/J5.jpg');

kt_download_media(2038, 'L2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/L2.jpg');

kt_download_media(2039, 'L3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/L3.jpg');

kt_download_media(2040, 'L5', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/L5.jpg');

kt_download_media(2041, 'S3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/S3.jpg');

kt_download_media(2042, 'S4', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/S4.jpg');
