<?php
//Menu
$menu_id = kt_add_menu( 56, 'footer Product', '' );

 // Menu Item
kt_add_menu_item( 914, $menu_id, 0, 'New In', 'custom', 914, 'custom', '#', '', '', '' );

kt_add_menu_item( 915, $menu_id, 0, 'Women', 'custom', 915, 'custom', '#', '', '', '' );

kt_add_menu_item( 916, $menu_id, 0, 'Men', 'custom', 916, 'custom', '#', '', '', '' );

kt_add_menu_item( 917, $menu_id, 0, 'Best Sellers', 'custom', 917, 'custom', '#', '', '', '' );

kt_add_menu_item( 918, $menu_id, 0, 'Top Brands', 'custom', 918, 'custom', '#', '', '', '' );

kt_add_menu_item( 919, $menu_id, 0, 'Sale & Special Offers', 'custom', 919, 'custom', '#', '', '', '' );

kt_add_menu_item( 920, $menu_id, 0, 'Lookbook', 'custom', 920, 'custom', '#', '', '', '' );
