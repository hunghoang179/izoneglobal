<?php
kt_download_media(2007, 'F1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/F1.jpg');

kt_download_media(2008, 'I1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/I1.jpg');

kt_download_media(2009, 'J1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/J1.jpg');

kt_download_media(2010, 'K1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/K1.jpg');

kt_download_media(2011, '28', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/28.png');

kt_download_media(2012, '29', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/29.png');
