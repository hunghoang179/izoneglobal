<?php
kt_download_media(2165, 'b5', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/b5.jpg');

kt_download_media(2168, 'brand1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/brand1.png');

kt_download_media(2170, 'bg-box-acc1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/bg-box-acc1.png');

kt_download_media(2171, 'bg-box-men', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/bg-box-men.png');

kt_download_media(2172, 'bg-box-women', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/bg-box-women.png');

kt_download_media(2203, 'payment', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/payment.jpg');

kt_download_media(2209, 'band1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band1.png');
