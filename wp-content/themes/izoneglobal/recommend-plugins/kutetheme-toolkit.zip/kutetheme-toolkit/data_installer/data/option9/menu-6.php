<?php
//Menu
$menu_id = kt_add_menu( 58, 'Sport1', '' );

 // Menu Item
kt_add_menu_item( 909, $menu_id, 0, 'Tennis', 'custom', 909, 'custom', '#', '', '', '' );

kt_add_menu_item( 910, $menu_id, 0, 'Football', 'custom', 910, 'custom', '#', '', '', '' );

kt_add_menu_item( 911, $menu_id, 0, 'Swimming', 'custom', 911, 'custom', '#', '', '', '' );

kt_add_menu_item( 912, $menu_id, 0, 'Basketballs', 'custom', 912, 'custom', '#', '', '', '' );

kt_add_menu_item( 913, $menu_id, 0, 'Volleyball', 'custom', 913, 'custom', '#', '', '', '' );
