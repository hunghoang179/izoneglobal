<?php
kt_download_media(2147, '11', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/111.jpg');

kt_download_media(2156, '64', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/642.jpg');

kt_download_media(2157, '66', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/662.jpg');

kt_download_media(2158, '67', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/671.jpg');

kt_download_media(2200, 'P2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/P22.jpg');
