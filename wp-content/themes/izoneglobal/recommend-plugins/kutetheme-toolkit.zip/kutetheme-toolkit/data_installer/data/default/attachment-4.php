<?php
kt_download_media(1882, 's3', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/s3.png');

kt_download_media(1883, 's4', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/s4.png');

kt_download_media(2003, '1.jpg', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/revslider/Slide1/1.jpg');

kt_download_media(2004, '1.1.jpg', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/revslider/Slide1/1.1.jpg');

kt_download_media(2005, 'line1.png', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/revslider/Slide1/line1.png');

kt_download_media(2006, 'E1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/E1.jpg');
