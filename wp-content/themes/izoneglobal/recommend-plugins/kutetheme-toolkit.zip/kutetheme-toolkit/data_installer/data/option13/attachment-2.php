<?php
kt_download_media(2009, '7', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/7.jpg');

kt_download_media(2011, '8', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/8.jpg');
