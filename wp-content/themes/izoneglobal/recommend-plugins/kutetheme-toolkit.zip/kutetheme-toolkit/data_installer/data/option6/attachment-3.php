<?php
kt_download_media(847, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(848, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog8.jpg');

kt_download_media(849, 'blog4', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(850, 'blog3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(851, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(853, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(861, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog12.jpg');
