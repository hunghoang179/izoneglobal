<?php
// Attachment
kt_download_media(560, 'i 8', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-8.jpg');

kt_download_media(561, 'i 6', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-6.jpg');

kt_download_media(562, 'i 7', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-7.jpg');

kt_download_media(563, 'i 37', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-37.jpg');

kt_download_media(564, 'i 10', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-10.jpg');
