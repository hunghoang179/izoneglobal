<?php
kt_download_media(2142, 'trademark-wu', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-wu.jpg');

kt_download_media(2143, 'men', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/men.png');

kt_download_media(2144, 'women', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/women.png');

kt_download_media(2145, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/kid.png');

kt_download_media(2146, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trending.png');

kt_download_media(2147, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/banner-topmenu.jpg');
