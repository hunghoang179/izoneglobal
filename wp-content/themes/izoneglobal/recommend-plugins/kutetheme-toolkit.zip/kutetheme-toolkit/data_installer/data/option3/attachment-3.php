<?php
kt_download_media(2006, 'E3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/E3.jpg');

kt_download_media(2007, 'Y2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Y2.jpg');

kt_download_media(2008, 'Y2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Y21.jpg');

kt_download_media(2009, 'Y3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/Y3.jpg');
