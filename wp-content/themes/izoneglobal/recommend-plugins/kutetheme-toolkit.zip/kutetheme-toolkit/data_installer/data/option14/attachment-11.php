<?php
kt_download_media(2087, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog81.jpg');

kt_download_media(2088, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog112.jpg');

kt_download_media(2089, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog221.jpg');
