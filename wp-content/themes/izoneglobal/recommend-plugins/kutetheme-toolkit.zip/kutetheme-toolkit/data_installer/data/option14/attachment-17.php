<?php
kt_download_media(2127, 'b3', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/b3.jpg');

kt_download_media(2128, 'b4', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/b4.jpg');

kt_download_media(2129, 'b5', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/b5.jpg');
