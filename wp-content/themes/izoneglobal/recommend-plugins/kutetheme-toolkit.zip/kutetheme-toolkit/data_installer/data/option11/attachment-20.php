<?php

kt_download_media(917, '73', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/73.jpg');

kt_download_media(919, '72', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/72.jpg');

kt_download_media(921, '69', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/69.jpg');

kt_download_media(922, '74', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/74.jpg');

kt_download_media(943, 'slide-left', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/slide-left.jpg');

kt_download_media(944, 'slide-left2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/slide-left2.jpg');
