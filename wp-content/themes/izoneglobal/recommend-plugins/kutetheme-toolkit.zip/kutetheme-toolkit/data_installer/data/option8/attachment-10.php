<?php
kt_download_media(2068, '4692neopren-gorunumlu-puantiyeli-elbise9495', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4692neopren-gorunumlu-puantiyeli-elbise9495.jpg');

kt_download_media(2069, '4592cicekli-elbise5918', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4592cicekli-elbise5918.jpg');

kt_download_media(2070, '4592cicekli-elbise7816', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4592cicekli-elbise7816.jpg');

kt_download_media(2071, '4682anvelop-v-yakali-elbise5486', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4682anvelop-v-yakali-elbise5486.jpg');
