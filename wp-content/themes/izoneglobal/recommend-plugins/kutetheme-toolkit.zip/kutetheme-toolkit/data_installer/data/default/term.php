<?php
// Custom term
kt_add_category( 198, '1.5 pixel', '1-5-pixel', 'pa_pixel', '0', '' );

kt_add_category( 194, '10kilogram', '10kilogram', 'pa_weight', '0', '' );

kt_add_category( 204, '14 inch', '14-inch', 'pa_inch', '0', '' );

kt_add_category( 199, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 203, '21 inch', '21-inch', 'pa_inch', '0', '' );

kt_add_category( 195, '2liter', '2liter', 'pa_liter', '0', '' );

kt_add_category( 205, '32 inch', '32-inch', 'pa_inch', '0', '' );

kt_add_category( 11, '34', '34', 'pa_size', '0', '' );

kt_add_category( 12, '35', '35', 'pa_size', '0', '' );

kt_add_category( 13, '36', '36', 'pa_size', '0', '' );

kt_add_category( 14, '37', '37', 'pa_size', '0', '' );

kt_add_category( 196, '3liter', '3liter', 'pa_liter', '0', '' );

kt_add_category( 192, '5kilogram', '5kg', 'pa_weight', '0', '' );

kt_add_category( 197, '5liter', '5liter', 'pa_liter', '0', '' );

kt_add_category( 193, '7kilogram', '7kilogram', 'pa_weight', '0', '' );

kt_add_category( 15, 'active', 'active', 'product_tag', '0', '' );

kt_add_category( 16, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 17, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 18, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1044' );

kt_add_category( 19, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 20, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 171, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 22, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 23, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1038' );

kt_add_brand( 24, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1045' );

kt_add_category( 25, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 26, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 27, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 28, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_category( 172, 'Dark Brown', 'drank-brown', 'pa_color', '0', '' );

kt_add_category( 186, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 187, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 173, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 174, 'Grey', 'grey', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 32, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1046' );

kt_add_category( 175, 'Light Brown', 'light-brown', 'pa_color', '0', '' );

kt_add_category( 176, 'Light Pink', 'light-pink', 'pa_color', '0', '' );

kt_add_category( 177, 'Lightblue', 'lightblue', 'pa_color', '0', '' );

kt_add_category( 36, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 37, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1037' );

kt_add_category( 38, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 39, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1036' );

kt_add_category( 178, 'Maroon', 'maroon', 'pa_color', '0', '' );

kt_add_category( 185, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 41, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 42, 'moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 43, 'new', 'new', 'product_tag', '0', '' );

kt_add_category( 179, 'Orange', 'orange', 'pa_color', '0', '' );

kt_add_brand( 45, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '101' );

kt_add_category( 46, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 191, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 47, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 180, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 184, 'Plastic', 'plastic', 'pa_material', '0', '' );

kt_add_category( 49, 'playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 50, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 51, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1047' );

kt_add_category( 181, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 189, 'Ruby', 'ruby', 'pa_material', '0', '' );

kt_add_category( 190, 'Ruby', 'ruby', 'product_tag', '0', '' );

kt_add_category( 53, 'S', 's', 'pa_size', '0', '' );

kt_add_category( 54, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 55, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 188, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 56, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 57, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '1048' );

kt_add_category( 58, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 59, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 60, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 61, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 183, 'Wood', 'wood', 'pa_material', '0', '' );

kt_add_category( 62, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 63, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 64, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 65, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 66, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 182, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_product_cat( 82, 'Digital', 'digital', 'product_cat', '0', '', '463' );

kt_add_product_cat( 85, 'Accessories for iPad', 'accessories-for-ipad', 'product_cat', '82', '', '' );

kt_add_product_cat( 84, 'Accessories for iPhone', 'accessories-for-iphone', 'product_cat', '82', '', '' );

kt_add_product_cat( 86, 'Accessories for Tablet PC', 'accessories-for-tablet-pc', 'product_cat', '82', '', '' );

kt_add_product_cat( 121, 'Camera', 'camera', 'product_cat', '82', '', '' );

kt_add_product_cat( 68, 'Cameras &amp; Photo', 'cameras-photo', 'product_cat', '82', '', '0' );

kt_add_product_cat( 69, 'Computers &amp; Networking', 'computers-networking', 'product_cat', '82', '', '0' );

kt_add_product_cat( 132, 'Laptop', 'laptop', 'product_cat', '82', '', '' );

kt_add_product_cat( 134, 'Mobile', 'mobile', 'product_cat', '82', '', '' );

kt_add_product_cat( 136, 'Notebook', 'notebook', 'product_cat', '82', '', '' );

kt_add_product_cat( 74, 'Smartphone &amp; Tablets', 'smartphone-tablets', 'product_cat', '82', '', '0' );

kt_add_product_cat( 76, 'Television', 'television-2', 'product_cat', '82', '', '0' );

kt_add_product_cat( 87, 'Electronic', 'electronic', 'product_cat', '0', '', '462' );

kt_add_product_cat( 117, 'Air Conditional', 'air-conditional', 'product_cat', '87', '', '' );

kt_add_product_cat( 118, 'ARM', 'arm', 'product_cat', '87', '', '' );

kt_add_product_cat( 119, 'Batteries &amp; Chargers', 'batteries-chargers-electronic', 'product_cat', '87', '', '' );

kt_add_product_cat( 70, 'Flashlights &amp; Lamps', 'flashlights-lamps', 'product_cat', '87', '', '0' );

kt_add_product_cat( 131, 'Home Audio', 'home-audio-electronic', 'product_cat', '87', '', '' );

kt_add_product_cat( 135, 'Mp3 Player Accessories', 'mp3-player-accessories-electronic', 'product_cat', '87', '', '' );

kt_add_product_cat( 142, 'Theater', 'theater', 'product_cat', '87', '', '' );

kt_add_product_cat( 130, 'Headphone, Headset', 'headphone-headset-electronic', 'product_cat', '87', '', '' );

kt_add_product_cat( 88, 'Fashion', 'fashion', 'product_cat', '0', 'Fashion', '461' );

kt_add_product_cat( 71, 'Health &amp; Beauty Bags', 'health-beauty-bags', 'product_cat', '88', '', '0' );

kt_add_product_cat( 104, 'Health &amp; Beauty', 'health-beauty', 'product_cat', '71', '', '460' );

kt_add_product_cat( 105, 'Bath &amp; Body', 'bath-body', 'product_cat', '104', '', '' );

kt_add_product_cat( 107, 'Fragrances', 'fragrances', 'product_cat', '104', '', '' );

kt_add_product_cat( 108, 'Salon &amp; Spa Equipment', 'salon-spa-equipment', 'product_cat', '104', '', '' );

kt_add_product_cat( 106, 'Shaving &amp; Hair Removal', 'shaving-hair-removal', 'product_cat', '104', '', '' );

kt_add_product_cat( 89, 'Kids', 'kids', 'product_cat', '88', '', '0' );

kt_add_product_cat( 90, 'Mens', 'mens', 'product_cat', '88', '', '0' );

kt_add_product_cat( 91, 'Jackets', 'jackets', 'product_cat', '90', '', '' );

kt_add_product_cat( 94, 'Skirts', 'skirts', 'product_cat', '90', '', '' );

kt_add_product_cat( 95, 'Tops', 'tops', 'product_cat', '90', '', '' );

kt_add_product_cat( 201, 'Scarves', 'scarves', 'product_cat', '88', '', '0' );

kt_add_product_cat( 73, 'Shoes &amp; Accessories', 'shoes-accessories', 'product_cat', '88', '', '0' );

kt_add_product_cat( 200, 'T_Shirt', 't_shirt', 'product_cat', '88', '', '0' );

kt_add_product_cat( 96, 'Trending', 'trending', 'product_cat', '88', '', '' );

kt_add_product_cat( 97, 'Womens', 'womens', 'product_cat', '88', '', '0' );

kt_add_product_cat( 98, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 99, 'Furniture', 'furniture', 'product_cat', '0', '', '464' );

kt_add_product_cat( 120, 'Bedding', 'bedding', 'product_cat', '99', '', '' );

kt_add_product_cat( 123, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '99', '', '' );

kt_add_product_cat( 133, 'Loveseats', 'loveseats', 'product_cat', '99', '', '' );

kt_add_product_cat( 137, 'Office Furniture', 'office-furniture', 'product_cat', '99', '', '' );

kt_add_product_cat( 109, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 116, 'Accessories', 'accessories', 'product_cat', '109', '', '' );

kt_add_product_cat( 125, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '109', '', '' );

kt_add_product_cat( 128, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '109', '', '' );

kt_add_product_cat( 77, 'Jewelry &amp; Watches', 'jewelry-watches', 'product_cat', '109', '', '465' );

kt_add_product_cat( 80, 'Earring', 'earring', 'product_cat', '77', '', '' );

kt_add_product_cat( 78, 'Men Watches', 'men-watches', 'product_cat', '77', '', '' );

kt_add_product_cat( 81, 'Necklaces', 'necklaces', 'product_cat', '77', '', '' );

kt_add_product_cat( 79, 'Wedding Rings', 'wedding-rings', 'product_cat', '77', '', '' );

kt_add_product_cat( 139, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '109', '', '' );

kt_add_product_cat( 75, 'Sport &amp; Outdoors', 'sport-outdoor', 'product_cat', '0', '', '466' );

kt_add_product_cat( 122, 'Camping &amp; Hiking', 'camping-hiking', 'product_cat', '75', '', '' );

kt_add_product_cat( 126, 'Fishing', 'fishing', 'product_cat', '75', '', '' );

kt_add_product_cat( 129, 'Golf Supplies', 'golf-supplies', 'product_cat', '75', '', '' );

kt_add_product_cat( 138, 'Outdoor &amp; Traveling Supplies', 'outdoor-traveling-supplies', 'product_cat', '75', '', '' );

kt_add_product_cat( 110, 'Sports', 'sports', 'product_cat', '75', '', '0' );

kt_add_product_cat( 124, 'Climbing', 'climbing', 'product_cat', '110', '', '' );

kt_add_product_cat( 127, 'Football', 'football', 'product_cat', '110', '', '' );

kt_add_product_cat( 140, 'Swimming', 'swimming', 'product_cat', '110', '', '' );

kt_add_product_cat( 141, 'Tennis', 'tennis', 'product_cat', '110', '', '' );

kt_add_product_cat( 111, 'Toys &amp; Hobbies', 'toys-hobbies', 'product_cat', '0', '', '467' );

kt_add_product_cat( 113, 'Fpv System &amp; Parts', 'fpv-system-parts', 'product_cat', '111', '', '' );

kt_add_product_cat( 115, 'Helicopters &amp; Part', 'helicopters-part', 'product_cat', '111', '', '' );

kt_add_product_cat( 114, 'RC Cars &amp; Parts', 'rc-cars-parts', 'product_cat', '111', '', '' );

kt_add_product_cat( 112, 'Walkera', 'walkera', 'product_cat', '111', '', '' );

