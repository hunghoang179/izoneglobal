<?php
kt_download_media(2090, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2091, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2092, 'slide-left', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/slide-left.jpg');
