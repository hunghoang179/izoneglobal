<?php
// Attachment
kt_download_media(503, 'ads17', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/ads17.jpg');

kt_download_media(504, 'ads18', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/ads18.jpg');

kt_download_media(1087, '2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/21.jpg');

kt_download_media(1089, '6', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/6.jpg');

kt_download_media(1092, 'i 11', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/i-111.jpg');

kt_download_media(1095, '17', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/17.jpg');

kt_download_media(1131, 'icon-s3)', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s3.png');

kt_download_media(1133, 'icon-s5', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s5.png');

kt_download_media(1135, 'icon-s2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s2.png');

kt_download_media(1137, 'icon-s4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s4.png');

kt_download_media(1139, 'icon-s6', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s6.png');


kt_download_media(2149, '15', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/15.png');

kt_download_media(2150, '18', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/18.png');

kt_download_media(2151, '19', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/19.png');

kt_download_media(2152, '21', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/21.png');

kt_download_media(2153, '12', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/12.png');

kt_download_media(2154, '13', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/13.png');

kt_download_media(2155, '14', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/14.png');

kt_download_media(2156, '20', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/20.png');

kt_download_media(2157, '22', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/22.png');

kt_download_media(2158, 'blog-1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog-1.jpg');

kt_download_media(2160, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog1.jpg');

kt_download_media(2161, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog2.jpg');

kt_download_media(2162, 'blog-2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog-2.jpg');

kt_download_media(2163, 'blog3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog3.jpg');

kt_download_media(2164, 'blog-3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog-3.jpg');

kt_download_media(2165, 'blog4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog4.jpg');

kt_download_media(2166, 'blog-4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog-4.jpg');

kt_download_media(2167, 'blog-5', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/blog-5.jpg');
