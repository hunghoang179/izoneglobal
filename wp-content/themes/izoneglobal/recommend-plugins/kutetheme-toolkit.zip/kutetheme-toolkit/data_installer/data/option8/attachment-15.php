<?php
kt_download_media(2090, '11', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/11.png');

kt_download_media(2091, '12', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/12.png');

kt_download_media(2092, '13', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/13.png');

kt_download_media(2093, '14', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/14.png');
