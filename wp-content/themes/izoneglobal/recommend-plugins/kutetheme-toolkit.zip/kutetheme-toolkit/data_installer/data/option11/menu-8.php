<?php
//Menu
$menu_id = kt_add_menu( 49, 'footer Product', '' );

 // Menu Item
kt_add_menu_item( 194, $menu_id, 0, 'New In', 'custom', 194, 'custom', '#', '', '', '' );

kt_add_menu_item( 195, $menu_id, 0, 'Women', 'custom', 195, 'custom', '#', '', '', '' );

kt_add_menu_item( 196, $menu_id, 0, 'Men', 'custom', 196, 'custom', '#', '', '', '' );

kt_add_menu_item( 197, $menu_id, 0, 'Best Sellers', 'custom', 197, 'custom', '#', '', '', '' );

kt_add_menu_item( 198, $menu_id, 0, 'Top Brands', 'custom', 198, 'custom', '#', '', '', '' );

kt_add_menu_item( 199, $menu_id, 0, 'Sale & Special Offers', 'custom', 199, 'custom', '#', '', '', '' );

kt_add_menu_item( 200, $menu_id, 0, 'Lookbook', 'custom', 200, 'custom', '#', '', '', '' );
