<?php
kt_download_media(2092, 'i 2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-2.jpg');

kt_download_media(2093, 'i 4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-4.jpg');

kt_download_media(2136, '32', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/322.png');

kt_download_media(2137, 'i 6', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-62.jpg');

kt_download_media(2138, 'i 7', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-71.jpg');
