<?php
kt_download_media(2232, 'banner1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner1.jpg');

kt_download_media(2233, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner2.jpg');

kt_download_media(2234, 'adv3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/adv3.jpg');

kt_download_media(2250, 'payment-logo', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/payment-logo.png');

kt_download_media(2371, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog1.jpg');

kt_download_media(2372, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(2373, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2374, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog8.jpg');
