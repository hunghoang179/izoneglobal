<?php
kt_download_media(2094, 'payment-logo', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/payment-logo.png');

kt_download_media(2102, '15', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/15.png');

kt_download_media(2104, '425dik-yaka-kolsuz-uzun-elbise4848', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/425dik-yaka-kolsuz-uzun-elbise4848.jpg');

kt_download_media(2108, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog1.jpg');
