<?php
kt_download_media(2257, 'p55', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p55.jpg');

kt_download_media(2258, 'p56', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p56.jpg');

kt_download_media(2259, 'p57', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p57.jpg');

kt_download_media(2260, 'p58', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p58.jpg');

kt_download_media(2262, 'p54', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p54.jpg');
