<?php
kt_download_media(2412, 'slide-left', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/slide-left.jpg');

kt_download_media(2413, 'slide-left2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/slide-left2.jpg');

kt_download_media(2414, 'slide-left3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/slide-left3.png');

kt_download_media(2415, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog2.jpg');

kt_download_media(2416, 'testimonial', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/testimonial.jpg');

kt_download_media(2417, 'electronic', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/electronic.png');

kt_download_media(2418, 'sports&o', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/sportso.png');

kt_download_media(2410, 'payment-logo', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/payment-logo1.png');
