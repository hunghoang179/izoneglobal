<?php
kt_download_media(137, 'testimonials1', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/testimonials1.jpg');

kt_download_media(138, 'testimonials2', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/testimonials2.jpg');

kt_download_media(139, 'testimonials3', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/testimonials3.jpg');

kt_download_media(144, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog6.jpg');

kt_download_media(145, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/blog7.jpg');
