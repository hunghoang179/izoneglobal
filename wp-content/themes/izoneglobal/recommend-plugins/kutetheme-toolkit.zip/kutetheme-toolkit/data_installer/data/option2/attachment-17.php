<?php
kt_download_media(2124, 'p62', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p62.jpg');

kt_download_media(2125, 'p73', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p73.jpg');

kt_download_media(2126, 'p74', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p74.jpg');

kt_download_media(2127, 'p75', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p75.jpg');

kt_download_media(2128, 'p76', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p76.jpg');

kt_download_media(2129, 'p79', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p79.jpg');
