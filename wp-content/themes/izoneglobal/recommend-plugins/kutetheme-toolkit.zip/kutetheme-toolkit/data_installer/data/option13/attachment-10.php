<?php
kt_download_media(2106, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/banner-topmenu.jpg');

kt_download_media(2107, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/banner-topmenu1.jpg');

kt_download_media(2108, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/kid.png');

kt_download_media(2109, 'men', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/men.png');

kt_download_media(2110, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/trending.png');

kt_download_media(2111, 'women', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/women.png');
