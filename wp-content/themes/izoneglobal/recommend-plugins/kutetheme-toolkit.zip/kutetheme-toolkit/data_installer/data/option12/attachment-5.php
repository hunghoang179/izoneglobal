<?php
kt_download_media(2037, '29', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/29.jpg');

kt_download_media(2039, '1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/1.png');

kt_download_media(2040, 'bg13.png', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/revslider/kute-opt12/bg13.png');

kt_download_media(2041, 'line5.png', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/revslider/kute-opt12/line5.png');

kt_download_media(2042, 'bg31.png', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/revslider/kute-opt12/bg31.png');

kt_download_media(2043, 'bg22.png', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/revslider/kute-opt12/bg22.png');
