<?php
 // Widgets
kt_add_widget( 'search', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'recent-posts', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'archives', 'sidebar-primary', '2', 'YTozOntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'categories', 'sidebar-primary', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'meta', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'categories', 'sidebar-primary', '3', 'YTo0OntzOjU6InRpdGxlIjtzOjE1OiJCTE9HIENBVEVHT1JJRVMiO3M6NToiY291bnQiO2k6MDtzOjEyOiJoaWVyYXJjaGljYWwiO2k6MDtzOjg6ImRyb3Bkb3duIjtpOjA7fQ==', '3' );

kt_add_widget( 'kt_image', 'sidebar-primary', '1', 'YTo0OntzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6NToiX3NlbGYiO3M6NDoic2l6ZSI7TjtzOjEwOiJhdHRhY2htZW50IjtpOjcyMTt9', '1' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '3', 'YToyOntzOjU6InRpdGxlIjtzOjE1OiJSRUNFTlQgQ09NTUVOVFMiO3M6NjoibnVtYmVyIjtpOjU7fQ==', '3' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-primary', '1', 'YToxOntzOjU6InRpdGxlIjtzOjQ6IlRhZ3MiO30=', '1' );

kt_add_widget( 'kt_image', 'sidebar-primary', '2', 'YTo0OntzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6NToiX3NlbGYiO3M6NDoic2l6ZSI7TjtzOjEwOiJhdHRhY2htZW50IjtpOjcyMjt9', '2' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop', '1', 'YTo2OntzOjU6InRpdGxlIjtzOjEzOiJQcm9kdWN0IFR5cGVzIjtzOjc6Im9yZGVyYnkiO3M6NDoibmFtZSI7czo4OiJkcm9wZG93biI7aTowO3M6NToiY291bnQiO2k6MDtzOjEyOiJoaWVyYXJjaGljYWwiO3M6MToiMSI7czoxODoic2hvd19jaGlsZHJlbl9vbmx5IjtzOjE6IjEiO30=', '1' );

kt_add_widget( 'woocommerce_layered_nav_filters', 'sidebar-shop', '1', 'YToxOntzOjU6InRpdGxlIjtzOjE0OiJBY3RpdmUgRmlsdGVycyI7fQ==', '1' );

kt_add_widget( 'woocommerce_price_filter', 'sidebar-shop', '1', 'YToxOntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgcHJpY2UiO30=', '1' );

kt_add_widget( 'yith-woo-ajax-navigation', 'sidebar-shop', '1', 'YTo4OntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgQ29sb3IiO3M6OToiYXR0cmlidXRlIjtzOjU6ImNvbG9yIjtzOjEwOiJxdWVyeV90eXBlIjtzOjM6ImFuZCI7czo0OiJ0eXBlIjtzOjU6ImNvbG9yIjtzOjY6ImNvbG9ycyI7YToxMjp7aToxNzE7czo3OiIjMGMzYTkwIjtpOjE3MjtzOjc6IiM5NjRiMDAiO2k6MTczO3M6NzoiIzM2YTkzYyI7aToxNzQ7czo3OiIjNWYyMzYzIjtpOjE3NTtzOjc6IiNjZmM0YTYiO2k6MTc2O3M6NzoiI2ZhZWJkNyI7aToxNzc7czo3OiIjYWFiMmJkIjtpOjE3ODtzOjc6IiNjMTlhNmIiO2k6MTc5O3M6NzoiI2YzOWMxMSI7aToxODA7czo3OiIjZmY1Yjg0IjtpOjE4MTtzOjc6IiNmZjAwMDAiO2k6MTgyO3M6NzoiI2ZmYzAwMCI7fXM6MTA6Im11bHRpY29sb3IiO2E6MDp7fXM6NjoibGFiZWxzIjthOjA6e31zOjc6ImRpc3BsYXkiO3M6MzoiYWxsIjt9', '1' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '1', 'YTo0OntzOjU6InRpdGxlIjtzOjU6IkNvbG9yIjtzOjk6ImF0dHJpYnV0ZSI7czo1OiJjb2xvciI7czoxMjoiZGlzcGxheV90eXBlIjtzOjQ6Imxpc3QiO3M6MTA6InF1ZXJ5X3R5cGUiO3M6MzoiYW5kIjt9', '1' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjE0OiJGaWx0ZXIgYnkgc2l6ZSI7czo5OiJhdHRyaWJ1dGUiO3M6NDoic2l6ZSI7czoxMjoiZGlzcGxheV90eXBlIjtzOjQ6Imxpc3QiO3M6MTA6InF1ZXJ5X3R5cGUiO3M6MzoiYW5kIjt9', '2' );

kt_add_widget( 'widget_kt_slider', 'sidebar-shop', '1', 'YTo3OntzOjg6ImF1dG9wbGF5IjtiOjE7czo0OiJsb29wIjtiOjE7czoxMDoic2xpZGVzcGVlZCI7czozOiIyMDAiO3M6NToidGl0bGUiO2E6Mzp7aTowO3M6MDoiIjtpOjE7czowOiIiO2k6MjtzOjA6IiI7fXM6NToiaW1hZ2UiO2E6Mzp7aTowO3M6MzoiNzIyIjtpOjE7czozOiI3MjMiO2k6MjtzOjM6IjcyMSI7fXM6NDoibGluayI7YTozOntpOjA7czoxOiIjIjtpOjE7czoxOiIjIjtpOjI7czoxOiIjIjt9czo2OiJ0YXJnZXQiO047fQ==', '1' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjQ6IlRhZ3MiO30=', '2' );

kt_add_widget( 'widget_kt_product_special', 'sidebar-shop', '1', 'YTozOntzOjU6InRpdGxlIjtzOjE2OiJTUEVDSUFMIFBST0RVQ1RTIjtzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjt9', '1' );

kt_add_widget( 'widget_kt_testimonial', 'sidebar-shop', '1', 'YTo3OntzOjU6InRpdGxlIjtzOjEyOiJURVNUSU1PTklBTFMiO3M6ODoiYXV0b3BsYXkiO2I6MTtzOjQ6Imxvb3AiO2I6MTtzOjEwOiJzbGlkZXNwZWVkIjtzOjM6IjIwMCI7czo2OiJudW1iZXIiO3M6MToiMyI7czo3OiJvcmRlcmJ5IjtzOjQ6ImRhdGUiO3M6NToib3JkZXIiO3M6NDoiZGVzYyI7fQ==', '1' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop-single', '2', 'YTo2OntzOjU6InRpdGxlIjtzOjE4OiJQcm9kdWN0IENhdGVnb3JpZXMiO3M6Nzoib3JkZXJieSI7czo0OiJuYW1lIjtzOjg6ImRyb3Bkb3duIjtpOjA7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7czoxOiIxIjtzOjE4OiJzaG93X2NoaWxkcmVuX29ubHkiO2k6MDt9', '2' );

kt_add_widget( 'widget_kt_best_seller', 'sidebar-shop-single', '1', 'YTozOntzOjU6InRpdGxlIjtzOjEyOiJCZXN0IFNlbGxlcnMiO3M6NjoibnVtYmVyIjtzOjE6IjYiO3M6NzoicGVycGFnZSI7czoxOiIzIjt9', '1' );

kt_add_widget( 'widget_kt_slider', 'sidebar-shop-single', '2', 'YTo3OntzOjg6ImF1dG9wbGF5IjtiOjE7czoxMDoic2xpZGVzcGVlZCI7czozOiIyMDAiO3M6NToidGl0bGUiO2E6Mzp7aTowO3M6MDoiIjtpOjE7czowOiIiO2k6MjtzOjA6IiI7fXM6NToiaW1hZ2UiO2E6Mzp7aTowO3M6MzoiNzIxIjtpOjE7czozOiI3MjIiO2k6MjtzOjM6IjcyMyI7fXM6NDoibGluayI7YTozOntpOjA7czoxOiIjIjtpOjE7czoxOiIjIjtpOjI7czoxOiIjIjt9czo2OiJ0YXJnZXQiO047czo0OiJsb29wIjtiOjA7fQ==', '2' );

kt_add_widget( 'widget_kt_on_sale', 'sidebar-shop-single', '1', 'YTo0OntzOjU6InRpdGxlIjtzOjY6Ik9OU0FMRSI7czo2OiJudW1iZXIiO2k6MztzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjt9', '1' );

kt_add_widget( 'kt_image', 'sidebar-shop-single', '3', 'YTo0OntzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6NToiX3NlbGYiO3M6NDoic2l6ZSI7TjtzOjEwOiJhdHRhY2htZW50IjtpOjEyNTQ7fQ==', '3' );

kt_add_widget( 'nav_menu', 'footer-menu-1', '1', 'YToyOntzOjU6InRpdGxlIjtzOjc6IkNvbXBhbnkiO3M6ODoibmF2X21lbnUiO2k6MTYwO30=', '1' );

kt_add_widget( 'nav_menu', 'footer-menu-2', '2', 'YToyOntzOjU6InRpdGxlIjtzOjEwOiJNeSBBY2NvdW50IjtzOjg6Im5hdl9tZW51IjtpOjE3NDt9', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-3', '3', 'YToyOntzOjU6InRpdGxlIjtzOjc6IlN1cHBvcnQiO3M6ODoibmF2X21lbnUiO2k6MTgzO30=', '3' );

kt_add_widget( 'widget_kt_mailchimp', 'footer-social', '1', 'YToxMTp7czo1OiJ0aXRsZSI7czoxMDoiTkVXU0xFVFRFUiI7czo0OiJsaXN0IjtzOjA6IiI7czo2OiJvcHRfaW4iO3M6Mjoibm8iO3M6MTE6InRleHRfYmVmb3JlIjtzOjA6IiI7czoxMDoidGV4dF9hZnRlciI7czowOiIiO3M6NzoiY29udGVudCI7czo4NzoiU3VjY2VzcyEgIENoZWNrIHlvdXIgaW5ib3ggb3Igc3BhbSBmb2xkZXIgZm9yIGEgbWVzc2FnZSBjb250YWluaW5nIGEgY29uZmlybWF0aW9uIGxpbmsuIjtzOjY6ImxheW91dCI7czozOiJvbmUiO3M6MTQ6ImhlaWdodF9kZXNrdG9wIjtpOjA7czoxMzoiaGVpZ2h0X3RhYmxldCI7aTowO3M6MTM6ImhlaWdodF9tb2JpbGUiO2k6MDtzOjM6ImNzcyI7czowOiIiO30=', '1' );

kt_add_widget( 'widget_kt_social', 'footer-social', '1', 'YToxOntzOjY6Ind0aXRsZSI7czoxNToiTEVUJ1MgU09DSUFMSVpFIjt9', '1' );

kt_add_widget( 'widget_kt_trademark_payment', 'footer-payment', '1', 'YTo1OntzOjY6Ind0aXRsZSI7czoyNDoiQUNDRVBURUQgUEFZTUVOVCBNRVRIT0RTIjtzOjU6InRpdGxlIjthOjk6e2k6MDtzOjE3OiJQcmVmZXJyZWQgY2FycmllciI7aToxO3M6NDoiUWl3aSI7aToyO3M6MTM6Ildlc3Rlcm4gVW5pb24iO2k6MztzOjEzOiLkuK3lm70g6ZO26KGMIjtpOjQ7czo0OiJWaXNhIjtpOjU7czoxMDoiTWFzdGVyY2FyZCI7aTo2O3M6MzoiRW1zIjtpOjc7czozOiJEaGwiO2k6ODtzOjEzOiJGZWRleCBleHByZXNzIjt9czo1OiJpbWFnZSI7YTo5OntpOjA7czozOiIzOTAiO2k6MTtzOjM6IjM5MSI7aToyO3M6MzoiMzkyIjtpOjM7czozOiIzOTMiO2k6NDtzOjM6IjM5NCI7aTo1O3M6MzoiMzk1IjtpOjY7czozOiIzOTYiO2k6NztzOjM6IjM5NyI7aTo4O3M6MzoiMzk4Ijt9czo0OiJsaW5rIjthOjk6e2k6MDtzOjE6IiMiO2k6MTtzOjE6IiMiO2k6MjtzOjE6IiMiO2k6MztzOjE6IiMiO2k6NDtzOjE6IiMiO2k6NTtzOjE6IiMiO2k6NjtzOjE6IiMiO2k6NztzOjE6IiMiO2k6ODtzOjE6IiMiO31zOjY6InRhcmdldCI7Tjt9', '1' );

kt_add_widget( 'widget_kt_seo_keyword', 'footer-bottom', '1', 'YTo0OntzOjY6Ind0aXRsZSI7czoyMToiSE9UIFNFQVJDSEVEIEtFWVdPUkRTIjtzOjU6InRpdGxlIjthOjg6e2k6MDtzOjExOiJYaWFvbWlvIE1pMyI7aToxO3M6Mjc6IkRpZ2lmbGlwbyBQcm8gWFQgNzEyIFRhYmxldCI7aToyO3M6MTE6Ik1pIDMgUGhvbmVzIjtpOjM7czoxNDoiSXBob25lbyA2IFBsdXMiO2k6NDtzOjI3OiJXb21lbiYjMDM5O3MgTWVzc2VuZ2VyIEJhZ3MiO2k6NTtzOjc6IldhbGxldHMiO2k6NjtzOjIxOiJXb21lbiYjMDM5O3MgQ2x1dGNoZXMiO2k6NztzOjE1OiJCYWNrcGFja3MgVG90ZXMiO31zOjQ6ImxpbmsiO2E6ODp7aTowO3M6MToiIyI7aToxO3M6MToiIyI7aToyO3M6MToiIyI7aTozO3M6MToiIyI7aTo0O3M6MToiIyI7aTo1O3M6MToiIyI7aTo2O3M6MToiIyI7aTo3O3M6MToiIyI7fXM6NjoidGFyZ2V0IjtOO30=', '1' );

kt_add_widget( 'widget_kt_seo_keyword', 'footer-bottom', '2', 'YTo0OntzOjY6Ind0aXRsZSI7czozOiJUVlMiO3M6NToidGl0bGUiO2E6MTI6e2k6MDtzOjg6IlNvbnlvIFRWIjtpOjE7czoxMDoiU2Ftc2luZyBUViI7aToyO3M6NjoiTEdHIFRWIjtpOjM7czo5OiJPbmlkYWkgVFYiO2k6NDtzOjExOiJUb3NoaWJhbyBUViI7aTo1O3M6MTE6IlBoaWxpcHNpIFRWIjtpOjY7czoxMjoiTWljcm9tYXhvIFRWIjtpOjc7czo2OiJMRUQgVFYiO2k6ODtzOjY6IkxDRCBUViI7aTo5O3M6OToiUGxhc21hIFRWIjtpOjEwO3M6NToiM0QgVFYiO2k6MTE7czo4OiJTbWFydCBUViI7fXM6NDoibGluayI7YToxMjp7aTowO3M6MToiIyI7aToxO3M6MToiIyI7aToyO3M6MToiIyI7aTozO3M6MToiIyI7aTo0O3M6MToiIyI7aTo1O3M6MToiIyI7aTo2O3M6MToiIyI7aTo3O3M6MToiIyI7aTo4O3M6MToiIyI7aTo5O3M6MToiIyI7aToxMDtzOjE6IiMiO2k6MTE7czoxOiIjIjt9czo2OiJ0YXJnZXQiO047fQ==', '2' );

kt_add_widget( 'widget_kt_seo_keyword', 'footer-bottom', '3', 'YTo0OntzOjY6Ind0aXRsZSI7czo3OiJNT0JJTEVTIjtzOjU6InRpdGxlIjthOjk6e2k6MDtzOjY6Ik1vdG8gRSI7aToxO3M6MTQ6IlNhbXNpbmcgTW9iaWxlIjtpOjI7czoxNjoiTWljcm9tYXhpIE1vYmlsZSI7aTozO3M6MTM6Ik5va2lhbiBNb2JpbGUiO2k6NDtzOjExOiJIVENpIE1vYmlsZSI7aTo1O3M6MTI6IlNvbnlvIE1vYmlsZSI7aTo2O3M6MTM6IkFwcGxlbyBNb2JpbGUiO2k6NztzOjEwOiJMR0cgTW9iaWxlIjtpOjg7czoxNToiS2FyYm9ubmkgTW9iaWxlIjt9czo0OiJsaW5rIjthOjk6e2k6MDtzOjE6IiMiO2k6MTtzOjE6IiMiO2k6MjtzOjE6IiMiO2k6MztzOjE6IiMiO2k6NDtzOjE6IiMiO2k6NTtzOjE6IiMiO2k6NjtzOjE6IiMiO2k6NztzOjE6IiMiO2k6ODtzOjE6IiMiO31zOjY6InRhcmdldCI7Tjt9', '3' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '4', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjc5O30=', '4' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '5', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE2MTt9', '5' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '6', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE1ODt9', '6' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '7', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE2OTt9', '7' );
