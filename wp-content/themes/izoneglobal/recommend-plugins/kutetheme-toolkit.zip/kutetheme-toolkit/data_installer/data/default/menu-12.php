<?php
//Menu
$menu_id = kt_add_menu( 177, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 1936, $menu_id, 0, 'Online Shopping', 'custom', 1936, 'custom', '#', '', '', '' );

kt_add_menu_item( 1937, $menu_id, 0, 'Promotions', 'custom', 1937, 'custom', '#', '', '', '' );

kt_add_menu_item( 1938, $menu_id, 0, 'My Orders', 'custom', 1938, 'custom', '#', '', '', '' );

kt_add_menu_item( 1939, $menu_id, 0, 'Help', 'custom', 1939, 'custom', '#', '', '', '' );

kt_add_menu_item( 1940, $menu_id, 0, 'Site Map', 'custom', 1940, 'custom', '#', '', '', '' );

kt_add_menu_item( 1941, $menu_id, 0, 'Customer Service', 'custom', 1941, 'custom', '#', '', '', '' );

kt_add_menu_item( 1942, $menu_id, 0, 'Support', 'custom', 1942, 'custom', '#', '', '', '' );
