<?php
kt_download_media(2065, '17', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/17.jpg');

kt_download_media(2066, '19', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/19.jpg');

kt_download_media(2067, '18', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/18.jpeg');

kt_download_media(2071, '60', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/60.jpg');

kt_download_media(2072, '63', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/63.jpg');

kt_download_media(2073, '69', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/69.jpg');

kt_download_media(2074, '64', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/64.jpg');

kt_download_media(2064, '16', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/16.jpg');
