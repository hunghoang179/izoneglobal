<?php
kt_download_media(565, 'i 11', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-11.jpg');

kt_download_media(566, '3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/32.jpg');

kt_download_media(568, '8', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/82.jpg');

kt_download_media(730, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog21.jpg');

kt_download_media(761, 'blog-full', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/blog-full.jpg');

kt_download_media(837, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner-topmenu1.jpg');
