<?php
//Menu
$menu_id = kt_add_menu( 173, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 1943, $menu_id, 0, 'Most Populars', 'custom', 1943, 'custom', '#', '', '', '' );

kt_add_menu_item( 1944, $menu_id, 0, 'Best Sellers', 'custom', 1944, 'custom', '#', '', '', '' );

kt_add_menu_item( 1945, $menu_id, 0, 'New Arrivals', 'custom', 1945, 'custom', '#', '', '', '' );

kt_add_menu_item( 1946, $menu_id, 0, 'Special Products', 'custom', 1946, 'custom', '#', '', '', '' );

kt_add_menu_item( 1947, $menu_id, 0, 'Manufacturers', 'custom', 1947, 'custom', '#', '', '', '' );

kt_add_menu_item( 1948, $menu_id, 0, 'Our Stores', 'custom', 1948, 'custom', '#', '', '', '' );

kt_add_menu_item( 1949, $menu_id, 0, 'Shipping', 'custom', 1949, 'custom', '#', '', '', '' );

kt_add_menu_item( 1950, $menu_id, 0, 'Payments', 'custom', 1950, 'custom', '#', '', '', '' );

kt_add_menu_item( 1951, $menu_id, 0, 'Payments', 'custom', 1951, 'custom', '#', '', '', '' );

kt_add_menu_item( 1952, $menu_id, 0, 'Refunds', 'custom', 1952, 'custom', '#', '', '', '' );
