<?php
//Menu
$menu_id = kt_add_menu( 161, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 1935, $menu_id, 0, 'Company Info - Partnerships', 'custom', 1935, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 163, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 1910, $menu_id, 0, 'Mobile', 'custom', 1910, 'custom', '#', '', '', '' );

kt_add_menu_item( 1911, $menu_id, 0, 'Tablets', 'custom', 1911, 'custom', '#', '', '', '' );

kt_add_menu_item( 1912, $menu_id, 0, 'Laptop', 'custom', 1912, 'custom', '#', '', '', '' );

kt_add_menu_item( 1913, $menu_id, 0, 'Memory Cards', 'custom', 1913, 'custom', '#', '', '', '' );

kt_add_menu_item( 1914, $menu_id, 0, 'Accessories', 'custom', 1914, 'custom', '#', '', '', '' );
