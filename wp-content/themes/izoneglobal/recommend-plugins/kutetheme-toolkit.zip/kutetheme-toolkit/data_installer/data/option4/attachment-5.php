<?php
kt_download_media(2022, 'I2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/I2.jpg');

kt_download_media(2023, 'I1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/I1.jpg');

kt_download_media(2024, 'I3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/I3.jpg');

kt_download_media(2035, 'J2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/J2.jpg');

kt_download_media(2036, 'J3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/J3.jpg');

kt_download_media(2037, 'J5', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/J5.jpg');

kt_download_media(2038, 'L2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/L2.jpg');

kt_download_media(2039, 'L3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/L3.jpg');
