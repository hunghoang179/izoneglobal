<?php
kt_download_media(93, '18', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/18.jpg');

kt_download_media(94, '19', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/19.jpg');

kt_download_media(95, '20', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/20.jpg');

kt_download_media(96, '21', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/21.jpg');

kt_download_media(97, '22', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/22.jpg');

