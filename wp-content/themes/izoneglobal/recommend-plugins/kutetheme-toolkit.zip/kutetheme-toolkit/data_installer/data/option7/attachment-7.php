<?php
kt_download_media(2265, '27', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/27.jpg');

kt_download_media(2266, '28', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/28.jpg');

kt_download_media(2267, '29', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/29.jpg');

kt_download_media(2268, '30', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/30.jpg');

kt_download_media(2269, '31', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/31.jpg');

kt_download_media(2270, '32', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/32.jpg');
