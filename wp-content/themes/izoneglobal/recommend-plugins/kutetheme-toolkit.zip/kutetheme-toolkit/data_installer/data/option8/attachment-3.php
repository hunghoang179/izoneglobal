<?php
kt_download_media(2028, 'collection1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection1.jpg');

kt_download_media(2029, 'collection2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection2.jpg');

kt_download_media(2030, 'collection3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection3.jpg');

kt_download_media(2031, 'collection4', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection4.jpg');
