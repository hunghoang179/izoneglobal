<?php

//Menu
$menu_id = kt_add_menu( 61, 'Asian', '' );

 // Menu Item
kt_add_menu_item( 884, $menu_id, 0, 'Vietnamese Pho', 'custom', 884, 'custom', '#', '', '0', '' );

kt_add_menu_item( 885, $menu_id, 0, 'Noodles', 'custom', 885, 'custom', '#', '', '0', '' );

kt_add_menu_item( 886, $menu_id, 0, 'Seafood', 'custom', 886, 'custom', '#', '', '0', '' );
