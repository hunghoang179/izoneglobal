<?php

kt_download_media(2030, '22', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/22.jpg');

kt_download_media(2031, '23', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/23.jpg');

kt_download_media(2032, '24', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/24.jpg');

kt_download_media(2033, '25', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/25.jpg');

kt_download_media(2034, '26', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/26.jpg');

kt_download_media(2035, '27', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/27.jpg');

kt_download_media(2036, '28', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/28.jpg');
