<?php
// Categories
kt_add_category(34,'About Beauty','about-beauty','category','0','');

kt_add_category(35,'Baby &amp; Mum','baby-mum','category','0','');

kt_add_category(36,'Diet &amp; Fitness','diet-fitness','category','0','');

kt_add_category(37,'News','news','category','0','');

kt_add_category(38,'Promotions','promotions','category','0','');

kt_add_category(1,'Uncategorized','uncategorized','category','0','');
