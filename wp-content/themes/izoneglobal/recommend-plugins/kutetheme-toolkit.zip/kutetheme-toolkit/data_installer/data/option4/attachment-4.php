<?php
kt_download_media(2013, 'F5', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/F5.jpg');

kt_download_media(2014, 'size-chart', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/size-chart.jpg');

kt_download_media(2016, 'R3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/R3.jpg');

kt_download_media(2017, 'R4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/R4.jpg');

kt_download_media(2018, 'R5', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/R5.jpg');

kt_download_media(2019, 'P2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/P2.jpg');

kt_download_media(2020, 'P1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/P1.jpg');

kt_download_media(2021, 'P3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/P3.jpg');
