<?php
kt_download_media(2104, 'm4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m4.jpg');

kt_download_media(2105, 'm1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m1.jpg');

kt_download_media(2106, 'm2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/m2.jpg');

kt_download_media(2107, 'banner-intab2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-intab2.jpg');

kt_download_media(2108, 'banner-intab', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-intab.jpg');

kt_download_media(2109, 'banner-botom1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-botom1.jpg');
