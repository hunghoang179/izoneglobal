<?php 
// Attachment
kt_download_media(2007, '1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/1.jpg');

kt_download_media(2008, '2', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/2.jpg');

kt_download_media(2009, '3', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/3.jpg');

kt_download_media(2010, '4', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/4.jpg');

kt_download_media(2011, '5', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/5.jpg');

kt_download_media(2012, '6', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/6.jpg');
