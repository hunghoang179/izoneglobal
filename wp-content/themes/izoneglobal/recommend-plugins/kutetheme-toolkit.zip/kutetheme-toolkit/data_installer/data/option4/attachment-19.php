<?php
kt_download_media(2435, 'adv1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/adv11.jpg');

kt_download_media(2436, 'adv2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/adv2.jpg');

kt_download_media(2437, 'adv3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/adv31.jpg');

kt_download_media(2438, 'adv4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/adv4.jpg');

kt_download_media(2439, 'banner1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner11.jpg');

kt_download_media(2440, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner21.jpg');

kt_download_media(2447, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/banner-megamenu.jpg');

kt_download_media(2427, 'Lap&acc', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/Lapacc.png');
