<?php
kt_download_media(2067, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2086, '1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/1.png');

kt_download_media(2087, '2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/2.png');

kt_download_media(2088, '3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/3.png');

kt_download_media(2089, '4', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/4.png');

kt_download_media(2090, '5', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/5.png');
