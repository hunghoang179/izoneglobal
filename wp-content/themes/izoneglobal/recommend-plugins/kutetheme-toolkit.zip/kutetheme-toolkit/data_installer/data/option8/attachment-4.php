<?php
kt_download_media(2032, 'collection5', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection5.jpg');

kt_download_media(2033, 'collection6', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/collection6.jpg');

kt_download_media(2041, 'loock-boock1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/loock-boock1.jpg');

kt_download_media(2042, 'loock-boock2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/loock-boock2.jpg');
