<?php
kt_download_media(2086, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(2087, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2088, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog8.jpg');

kt_download_media(2089, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog11.jpg');

kt_download_media(2090, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2092, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2093, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/blog41.jpg');
