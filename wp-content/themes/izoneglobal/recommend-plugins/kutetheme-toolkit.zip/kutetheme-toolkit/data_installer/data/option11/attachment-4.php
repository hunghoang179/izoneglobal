<?php
kt_download_media(49, '12', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/121.png');

kt_download_media(50, '13', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/131.png');

kt_download_media(51, '14', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/141.png');

kt_download_media(52, '15', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/151.png');

kt_download_media(53, '16', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/161.png');

kt_download_media(54, '17', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/171.png');
