<?php
kt_download_media(2091, 'icon-furniture', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-furniture.png');

kt_download_media(2092, 'banner-product1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-product1.jpg');

kt_download_media(2093, 'banner-product2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-product2.jpg');

kt_download_media(2094, 'banner-product3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/banner-product3.jpg');

kt_download_media(2096, 'icon-sports', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-sports.png');

kt_download_media(2097, 'sport2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/sport2.jpg');
