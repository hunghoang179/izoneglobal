<?php
kt_download_media(55, '18', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/181.png');

kt_download_media(56, '19', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/191.png');

kt_download_media(57, '20', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/201.png');

kt_download_media(88, '13', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/13.jpg');

kt_download_media(89, '14', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/14.jpg');

kt_download_media(90, '15', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/15.jpg');
