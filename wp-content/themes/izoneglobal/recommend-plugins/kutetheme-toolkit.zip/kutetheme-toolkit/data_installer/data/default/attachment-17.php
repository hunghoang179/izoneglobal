<?php

kt_download_media(2076, 'pm2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/pm2.jpg');

kt_download_media(2077, '24', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/24.jpg');

kt_download_media(2078, '25', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/25.jpg');

kt_download_media(2079, '26', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/26.jpg');

kt_download_media(2080, 'cn2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/cn2.jpg');
