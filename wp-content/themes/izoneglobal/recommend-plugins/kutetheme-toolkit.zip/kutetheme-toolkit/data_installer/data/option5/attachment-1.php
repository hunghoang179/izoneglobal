<?php
// Attachment
kt_download_media(1223, 'O2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/O21.jpg');

kt_download_media(1224, 'O4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/O4.jpg');

kt_download_media(1231, 'O1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/O11.jpg');

kt_download_media(1232, 'E1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/E12.jpg');

kt_download_media(1246, 'F1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/F11.jpg');

kt_download_media(1247, 'L2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/L21.jpg');

kt_download_media(1248, 'L5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/L5.jpg');


kt_download_media(2289, 'trademark-cn', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-cn.jpg');

kt_download_media(2290, 'trademark-dhl', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-dhl.jpg');

kt_download_media(2291, 'trademark-ems', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-ems.jpg');

kt_download_media(2292, 'trademark-fe', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-fe.jpg');

kt_download_media(2293, 'trademark-mc', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-mc.jpg');

kt_download_media(2294, 'trademark-qiwi', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-qiwi.jpg');

kt_download_media(2295, 'trademark-ups', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-ups.jpg');

kt_download_media(2296, 'trademark-visa', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-visa.jpg');

kt_download_media(2297, 'trademark-wm', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-wm.jpg');

kt_download_media(2298, 'trademark-wu', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/trademark-wu.jpg');
