<?php
kt_download_media(2121, '49', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/49.jpg');

kt_download_media(2122, '50', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/50.jpg');

kt_download_media(2123, '51', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/51.jpg');

kt_download_media(2124, '52', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/52.jpg');

kt_download_media(2125, '55', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/55.jpg');

kt_download_media(2126, '56', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/56.jpg');
