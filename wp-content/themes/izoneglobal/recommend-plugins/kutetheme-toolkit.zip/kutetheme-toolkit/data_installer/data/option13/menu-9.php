<?php
//Menu
$menu_id = kt_add_menu( 165, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 1988, $menu_id, 0, 'Skirts', 'custom', 1988, 'custom', '#', '', '', '' );

kt_add_menu_item( 1989, $menu_id, 0, 'Jackets', 'custom', 1989, 'custom', '#', '', '', '' );

kt_add_menu_item( 1990, $menu_id, 0, 'Tops', 'custom', 1990, 'custom', '#', '', '', '' );

kt_add_menu_item( 1991, $menu_id, 0, 'Scarves', 'custom', 1991, 'custom', '#', '', '', '' );

kt_add_menu_item( 1992, $menu_id, 0, 'Pants', 'custom', 1992, 'custom', '#', '', '', '' );
