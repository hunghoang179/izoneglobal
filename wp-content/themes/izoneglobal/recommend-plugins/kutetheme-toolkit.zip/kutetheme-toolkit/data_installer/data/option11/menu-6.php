<?php
//Menu
$menu_id = kt_add_menu( 50, 'footer CUSTOMER SERVICE', '' );

 // Menu Item
kt_add_menu_item( 201, $menu_id, 0, 'Advanced Search', 'custom', 201, 'custom', '#', '', '', '' );

kt_add_menu_item( 202, $menu_id, 0, 'Orders and Returns', 'custom', 202, 'custom', '#', '', '', '' );

kt_add_menu_item( 203, $menu_id, 0, 'Contact Us', 'custom', 203, 'custom', '#', '', '', '' );

kt_add_menu_item( 204, $menu_id, 0, 'RSS', 'custom', 204, 'custom', '#', '', '', '' );

kt_add_menu_item( 205, $menu_id, 0, 'Help & FAQs', 'custom', 205, 'custom', '#', '', '', '' );

kt_add_menu_item( 206, $menu_id, 0, 'Consultant', 'custom', 206, 'custom', '#', '', '', '' );

kt_add_menu_item( 207, $menu_id, 0, 'Store Locations', 'custom', 207, 'custom', '#', '', '', '' );
