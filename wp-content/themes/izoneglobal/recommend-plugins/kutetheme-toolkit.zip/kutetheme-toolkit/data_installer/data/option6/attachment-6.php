<?php
kt_download_media(1024, 'Jewelry', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/Jewelry4.png');

kt_download_media(1025, 'Flashlights', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/Flashlights1.png');

kt_download_media(1108, 'banner-bottom2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner-bottom2.jpg');

kt_download_media(1117, 'banner-botom1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner-botom1.jpg');

kt_download_media(1128, 'icon-service1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-service1.png');

kt_download_media(1131, 'icon-s3)', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-s3.png');
