<?php
kt_download_media(1532, 'banner11', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner111.jpg');

kt_download_media(1533, 'banner12', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner12.jpg');

kt_download_media(1563, 'ads-banner', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/ads-banner.jpg');

kt_download_media(1565, 'banner', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner.jpg');

kt_download_media(1590, 'banner6', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner6.jpg');

kt_download_media(1592, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/banner-megamenu.jpg');
